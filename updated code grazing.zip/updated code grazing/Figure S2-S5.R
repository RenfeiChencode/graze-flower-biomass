library(ggplot2)
library(scales)
library(patchwork)
df=read.csv("statis_difference appendix.csv")

title=c("1&&1","2&&2","3&&3","4&&4","10&&10","20&&20","30&&30","40&&40")
p=list()
#average distance
for (i in 1:8){
df2=df[i,1:3]
variables <- names(df2)
values <- unlist(df2)
df3 <- data.frame(
  variable = variables,
  value = values,
  stringsAsFactors = FALSE  
)
df3$Percentage <- df3$value / sum(df3$value)
df3$variable=ifelse(df3$variable == "avg_positive", "Convergent", 
                    ifelse(df3$variable == "avg_negative", "Divergent", 
                  ifelse(df3$variable =="avg_netural", "Neutral", df3$variable)))
p[[i]]=ggplot(df3, aes(x = "", y = value, fill = variable)) +
  labs(title = title[i])+
  geom_bar(stat = "identity", width = 1) +
  coord_polar("y", start = 0) +
  theme_void() + 
  geom_text(aes(label = ifelse(Percentage > 0, percent(Percentage), "")),  
            position = position_stack(vjust = 0.5),size=12) +
theme(plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
      legend.text =element_text(size = 16,color='black'),
      legend.title=element_blank(),
      legend.position = "bottom") 

}
p_avg_dis=(p[[1]]+p[[2]]+p[[3]]+p[[4]])/(p[[5]]+p[[6]]+p[[7]]+p[[8]])

p=list()
#total distance
for (i in 1:8){
  df2=df[i,4:6]
  variables <- names(df2)
  values <- unlist(df2)
  df3 <- data.frame(
    variable = variables,
    value = values,
    stringsAsFactors = FALSE  
  )
  df3$Percentage <- df3$value / sum(df3$value)
  df3$variable=ifelse(df3$variable == "tot_positive", "Convergent", 
                      ifelse(df3$variable == "tot_negative", "Divergent", 
                             ifelse(df3$variable =="tot_netural", "Neutral", df3$variable)))
  p[[i]]=ggplot(df3, aes(x = "", y = value, fill = variable)) +
    labs(title = title[i])+
    geom_bar(stat = "identity", width = 1) +
    coord_polar("y", start = 0) +
    theme_void() + 
    geom_text(aes(label = ifelse(Percentage > 0, percent(Percentage), "")), 
              position = position_stack(vjust = 0.5),size=12) +
    theme(plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                    margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
          legend.text =element_text(size = 16,color='black'),
          legend.title=element_blank(),
          legend.position = "bottom") 
  
}
p_tot_dis=(p[[1]]+p[[2]]+p[[3]]+p[[4]])/(p[[5]]+p[[6]]+p[[7]]+p[[8]])

p=list()
#flowering time median
for (i in 1:8){
  df2=df[i,7:9]
  variables <- names(df2)
  values <- unlist(df2)
  df3 <- data.frame(
    variable = variables,
    value = values,
    stringsAsFactors = FALSE
  )
  df3$Percentage <- df3$value / sum(df3$value)
  df3$variable=ifelse(df3$variable == "flowert_positive", "Advance", 
                      ifelse(df3$variable == "flowert_negative", "Delay", 
                             ifelse(df3$variable =="flowert_netural", "Neutral", df3$variable)))
  p[[i]]=ggplot(df3, aes(x = "", y = value, fill = variable)) +
    labs(title = title[i])+
    geom_bar(stat = "identity", width = 1) +
    coord_polar("y", start = 0) +
    theme_void() + 
    geom_text(aes(label = ifelse(Percentage > 0, percent(Percentage), "")),  
              position = position_stack(vjust = 0.5),size=12) +
    theme(plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                    margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
          legend.text =element_text(size = 16,color='black'),
          legend.title=element_blank(),
          legend.position = "bottom") 
  
}
p_flower_medianD=(p[[1]]+p[[2]]+p[[3]]+p[[4]])/(p[[5]]+p[[6]]+p[[7]]+p[[8]])

p=list()

for (i in 1:8){
  df2=df[i,10:12]
  variables <- names(df2)
  values <- unlist(df2)
  df3 <- data.frame(
    variable = variables,
    value = values,
    stringsAsFactors = FALSE  
  )
  df3$Percentage <- df3$value / sum(df3$value)
  df3$variable=ifelse(df3$variable == "min_extre_positive", "Stable", 
                      ifelse(df3$variable == "min_extre_negative", "Unstable", 
                             ifelse(df3$variable =="min_extre_netural", "Neutral", df3$variable)))

  p[[i]]=ggplot(df3, aes(x = "", y = value, fill = variable)) +
    labs(title = title[i])+
    geom_bar(stat = "identity", width = 1) +
    coord_polar("y", start = 0) +
    theme_void() + 
    geom_text(aes(label = ifelse(Percentage > 0, percent(Percentage), "")),  
              position = position_stack(vjust = 0.5),size=12) +
    theme(plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                    margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
          legend.text =element_text(size = 16,color='black'),
          legend.title=element_blank(),
          legend.position = "bottom") 
  
}
p_min_extre=(p[[1]]+p[[2]]+p[[3]]+p[[4]])/(p[[5]]+p[[6]]+p[[7]]+p[[8]])

#ggsave("averagedistance.pdf",p_avg_dis,width = 30, height = 60, units = "cm", dpi = 300) 
#ggsave("totaldistance.pdf",p_tot_dis,width = 30, height = 60, units = "cm", dpi = 300) 
#ggsave("mediandifference.pdf",p_flower_medianD,width = 30, height = 60, units = "cm", dpi = 300) 
#ggsave("num_minimum.pdf",p_min_extre,width = 30, height = 60, units = "cm", dpi = 300) 
