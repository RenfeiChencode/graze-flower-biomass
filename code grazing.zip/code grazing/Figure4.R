library(tidyverse)
library(ggtext)
library(ggdist)
library(geomtextpath)
library(glue)
library(patchwork)
library(rtry)
library(glmmTMB)#generalise linear mixed model
library(MASS)
library(mclust)
library(ggplot2)
library(pracma)#
library(dplyr)
########################################
df=read.csv("gr3.csv")
df$Grazed_f=factor(df$Grazed,levels = c(0, 1, 2))
df$Treatment=factor(df$Treatment..Name.of.the.experimental.treatment,levels = unique(df$Treatment..Name.of.the.experimental.treatment))
median_p <- median(df$Onsetflower, na.rm = TRUE)
sitename=unique(df$Location...Site.Name);p=list();distance_df=list();df4=df5=df6=data.frame();result_sig=list()
sitename=sitename[c(-5,-7,-11)];pvalue=NA
np=c(rep(3,6),2,4,3)
for (i in 1:9){
  df2=rtry_select_row(df,
                      (Location...Site.Name %in% sitename[i]),
                      getAncillary = TRUE)
  df3=data.frame(Onsetflower=df2$Onsetflower,Grazed=df2$Grazed)
  df3 <- na.omit(df3);df3$Grazed=ifelse(df3$Grazed == 0, "Banning", 
                                        ifelse(df3$Grazed == 1, "Low",
                                               ifelse(df3$Grazed == 2, "High", df3$Grazed)))
  df_split <- df3 %>% split(.$Grazed)
  medi_flower=list()
  for (group_name in names(df_split)) {
    sub_df <- df_split[[group_name]]
    pdf_obj=density(sub_df$Onsetflower)
    potential <- -log(pdf_obj$y + 1e-10)
    
    potential_data = data.frame(
      Onsetflower = pdf_obj$x, 
      Potential = potential,
      Grazed=rep(paste(group_name,sitename[i]),length(potential)),
      Site=rep(sitename[i],length(potential)),
      le=rep(group_name,length(potential))
    )
    df4=rbind(df4,potential_data)
    extrema <- which(diff(sign(diff(potential))) != 0)
    extrema_points <- potential_data[extrema, ]
    extrema_points$extype=ifelse(diff(sign(diff(potential)))[extrema] > 0, "Min", "Max")
    df5=rbind(df5,extrema_points)
    
    median_p = median(sub_df$Onsetflower)
    medi_flower[[group_name]]=sub_df
    num=table(extrema_points$extype);
    num_df=data.frame(Grazed=group_name,number_min=num["Min"],
                                                       median_group=paste(group_name,sitename[i]),median_p=median_p,site=sitename[i])
    df6=rbind(df6,num_df)
    
  }
  result_sig[[i]]=wilcox.test( medi_flower[[1]]$Onsetflower, medi_flower[[2]]$Onsetflower, exact = FALSE)

  pvalue=c(pvalue,rep(result_sig[[i]]$p.value,length(names(df_split))))
  
}
df6=cbind(df6,round(data.frame(pvalue=na.omit(pvalue)),3))
freq_min=df6 %>% group_by(Grazed, number_min)%>% summarise(count = n(),.groups = "drop") %>% mutate(frequency = count / sum(count))
freq_min$Grazed=factor(freq_min$Grazed,levels = c("Banning","Low", "High"))
FMIN=ggplot(freq_min, aes(x = Grazed, y = frequency, fill = as.factor(number_min))) +
  geom_bar(stat = "identity", position = "dodge")

# ========figure 4b============
df4low=subset(df4,df4$le=="Low");df5low=subset(df5,df5$le=="Low")
Potential_low=ggplot(df4low,aes(y=Potential,x = Onsetflower, group=Site,color= Site)) +geom_path(size=1.5) +
  geom_point(data=df5low, aes(y=Potential,x = Onsetflower, group=Site,color= Site), size=4)+
   labs(title = "Low grazing intensity", x = "Onset of flowering",y="",color="Site") +
   annotate("text",x=2.5, y=17.5, label="b",angle = 0,size=15,family="serif")+
   theme(axis.text=element_text(size=25,family="serif",colour = "black"),
         axis.text.x=element_text(size=25,family="serif",angle=0,colour = "black",vjust = 0.0),
         axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5,margin = margin(0,5,0,0)),
         axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
         axis.title.x = element_text(vjust=0.0),
         axis.line=element_line(size = 0.5, colour = "black", linetype=1),
         axis.ticks.length = unit(0.25, "cm"),
         axis.ticks = element_line(size = 1, color="black"),
         plot.background = element_rect(fill = "white", color = NA),
         panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
         panel.background = element_rect(fill = "white", color = NA),
         legend.text =element_text(size = 25,color='black'),
         legend.key.size = unit(2.2,'line'), # space between legend text
         # legend.title = element_text(size = 18,color='black'),
         legend.title=element_blank(),
         legend.position = c(0.58,0.88),
         legend.direction = "horizontal",
         plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                   margin = margin(b = 0.3, t = 0.4, l = 0, unit = "cm")),
         plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm")) + guides(color = guide_legend(nrow = 3))+
   scale_x_continuous(breaks=seq(0,300,by=100),limits=c(0,300))+
   scale_y_continuous(breaks=seq(0,18,by=6),limits=c(0,18))+guides(col = guide_legend(nrow = 3,override.aes = list(size = 2)))
 
# ========figure 4c============
df4high=subset(df4,df4$le=="High"); df5high=subset(df5,df5$le=="High")
Potential_high=ggplot(df4high,aes(y=Potential,x = Onsetflower, group=Site,color= Site)) +geom_path(size=1.5) +
  geom_point(data=df5high, aes(y=Potential,x = Onsetflower, group=Site,color= Site), size=4)+
  labs(title = "High grazing intensity", x = "Onset of flowering",color="Site") +
  annotate("text",x=0.5, y=18.0, label="c",angle = 0,size=15,family="serif")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x=element_text(size=25,family="serif",angle=0,colour = "black",vjust = 0.0),
        axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5,margin = margin(0,5,0,0)),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA),
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.text =element_text(size = 25,color='black'),
        legend.key.size = unit(2.2,'line'), # space between legend text
        # legend.title = element_text(size = 18,color='black'),
        legend.title=element_blank(),
        legend.position = c(0.58,0.88),
        legend.direction = "horizontal",
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = 0.3, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm")) +
  scale_x_continuous(breaks=seq(0,300,by=100),limits=c(0,300))+
  scale_y_continuous(breaks=seq(0,18,by=6),limits=c(0,18))+guides(col = guide_legend(nrow = 2,override.aes = list(size = 2)))

# ========figure 4a============
df4ban=subset(df4,df4$le=="Banning");df5ban=subset(df5,df5$le=="Banning")
Potential_ban=ggplot(df4ban,aes(y=Potential,x = Onsetflower, group=Site,color= Site)) +geom_path(size=1.5) +
  geom_point(data=df5ban, aes(y=Potential,x = Onsetflower, group=Site,color= Site), size=4)+
  labs(title = "No grazing", x = "",color="Site") +
  annotate("text",x=2.5, y=17.5, label="a",angle = 0,size=16,family="serif")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x=element_text(size=25,family="serif",angle=0,colour = "black",vjust = 0.0),
        axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5,margin = margin(0,5,0,0)),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA),
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.text =element_text(size = 25,color='black'),
        legend.key.size = unit(2.2,'line'), # space between legend text
        # legend.title = element_text(size = 18,color='black'),
        legend.title=element_blank(),
        legend.position = c(0.68,0.88),
        legend.direction = "horizontal",
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = 0.3, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm")) +
  scale_x_continuous(breaks=seq(0,300,by=100),limits=c(0,300))+
  scale_y_continuous(breaks=seq(0,18,by=6),limits=c(0,18))+ guides(col = guide_legend(nrow = 2,override.aes = list(size = 2)))

# ========figure 4e============
 df7=data.frame(group=c("Advance","Neutral","Delay"),value=c(2/9, 4/9, 3/9))#
 df7$group=factor(df7$group,levels = c("Advance","Neutral","Delay"))
 df7$labal=sprintf("%.2f%%", df7$value * 100)#
 MEDIAN_plot=ggplot(df7, aes(x = group, y = value)) +
   geom_bar(stat = "identity", position = "dodge",fill="blue")+
   labs(title = "Shift of onset of flowering", x = "Median difference", y = "Relative frequency") +
   annotate("text",x=0.55, y=0.85, label="e",angle = 0,size=15,family="serif",face = "bold")+
   annotate("text",x=1, y=0.35, label=df7$labal[1],angle = 0,size=9,family="serif")+
   annotate("text",x=2, y=0.57, label=df7$labal[2],angle = 0,size=9,family="serif")+
   annotate("text",x=3, y=0.45, label=df7$labal[3],angle = 0,size=9,family="serif")+
   theme(axis.text=element_text(size=25,family="serif",colour = "black"),
         axis.text.x=element_text(size=28,family="serif",angle=0,colour = "black",vjust = 0.0),
         axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5,margin = margin(0,5,0,0)),
         axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
         axis.title.x = element_text(vjust=0.0),
         axis.line=element_line(size = 0.5, colour = "black", linetype=1),
         axis.ticks.length = unit(0.25, "cm"),
         axis.ticks = element_line(size = 1, color="black"),
         plot.background = element_rect(fill = "white", color = NA), 
         panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
         panel.background = element_rect(fill = "white", color = NA),
         plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                   margin = margin(b = 0.3, t = 0.4, l = 0, unit = "cm")),
         plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm")) +
   scale_y_continuous(breaks=seq(0,0.9,by=0.3),limits=c(0,0.9))

 
# ========figure 4d============
df8=data.frame(group=c("Banning","Banning","Low","Low","High"),value=c(freq_min$frequency[1],1-freq_min$frequency[1],
                                                                       freq_min$frequency[7],1-freq_min$frequency[7],1))
df8$labal=c("Stable","Unstable","Stable","Unstable","Unstable")
df8$labper=sprintf("%.2f%%", df8$value * 100)
df8$group=factor(df8$group,levels = c("Banning","Low","High"))
stable_point=ggplot(df8, aes(x = group, y = value,fill=labal)) +geom_bar(stat = "identity", position = "dodge")+
  labs(title = "Stability of onset of flowering", x = "Grazing intensity", y = "Relative frequency",fill="") +
  annotate("text",x=0.55, y=1.35, label="d",angle = 0,size=15,family="serif")+
  annotate("text",x=0.8, y=df8$value[1]+0.12, label=df8$labper[1],angle = 0,size=9,family="serif")+
  annotate("text",x=1.25, y=df8$value[2]+0.12, label=df8$labper[2],angle = 0,size=9,family="serif")+
  annotate("text",x=1.75, y=df8$value[3]+0.12, label=df8$labper[3],angle = 0,size=9,family="serif")+
  annotate("text",x=2.25, y=df8$value[4]+0.12, label=df8$labper[4],angle = 0,size=9,family="serif")+
  annotate("text",x=3, y=1.12, label=df8$labper[5],angle = 0,size=9,family="serif")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x=element_text(size=28,family="serif",angle=0,colour = "black",vjust = 0.0),
        axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5,margin = margin(0,5,0,0)),
        axis.title.x = element_text(vjust=0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        legend.position = c(0.75,0.88),
        legend.text =element_text(size = 25,color='black'),
        legend.direction = "horizontal",
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = 0.3, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm")) +
        
        scale_y_continuous(breaks=seq(0,1.5,by=0.5),limits=c(0,1.5))

###############################################################
ggsave("Figure 4.pdf",(Potential_ban|Potential_low)/(Potential_high|(stable_point/MEDIAN_plot)),width = 45, height = 45, units = "cm", dpi = 300) 


