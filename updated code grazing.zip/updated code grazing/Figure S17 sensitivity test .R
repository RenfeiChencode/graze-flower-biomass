library(ggplot2);library(gridExtra);library(scales);library(grid)
library(sqldf);library(dplyr);library(patchwork);library(ggsignif)
####################################################################
g14evo=read.table("figs17c025evo14.out")
g15evo=read.table("figs17c025evo15.out")
g16evo=read.table("figs17c025evo16.out")
tcol         <-  1
res1col      <-  2
res2col      <-  3
res3col      <-  4
totnumcol    <-  5
totbiocol    <-  6
h1numcol     <-  7
h1biocol     <-  8
h2numcol     <-  9
h2biocol     <- 10
h3numcol     <- 11
h3biocol     <- 12
h2juvnumcol  <- 13
h2juvbiocol  <- 14
h3juvnumcol  <- 15
h3juvbiocol  <- 16
h2adunumcol  <- 17
h2adubiocol  <- 18
h3adunumcol  <- 19
h3adubiocol  <- 20
smoltsizecol <- 21   
totreprocol  <- 22
numcohcol    <- 23
yieldjuvcol  <- 24
yieldaducol  <- 25
yieldtotcol  <- 26

#FigureS17 onset of flowering vs time

NN1=length(g14evo[,tcol]);NN2=length(g15evo[,tcol]);NN3=length(g16evo[,tcol])
class=c(rep("grazing intensity 1.4",NN1), rep("grazing intensity 1.5",NN2),rep("grazing intensity 1.6",NN3))
time=c(g14evo[,tcol],g15evo[,tcol],g16evo[,tcol])
WSevo=c(g14evo[,smoltsizecol], g15evo[,smoltsizecol],g16evo[,smoltsizecol])
dfevo=data.frame(WSevo=WSevo,class=class,time=time)
FigureS17=ggplot(data = dfevo,aes(x=time,y=WSevo,group=class,color=class))+geom_path(size=1)+
  #geom_vline(xintercept=500,colour="grey",lty="dashed",size=2)+
  #annotate("text",x=360, y=0.27, label="Protection start",colour="grey",angle = 90,size=10 ,family="serif")+
  annotate("text",x=1, y=0.38, label="",angle = 0,size=10,family="serif")+
  labs(title="Evolution",colour="",x="Time",y="Onset of flowering")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x = element_text(vjust=0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        line = element_blank(),
        legend.key = element_blank(),
        legend.position = c(0.68,0.8), 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 20,color='black'),
        legend.title = element_text(size=25, face = "bold"),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm") )+
  scale_x_continuous(breaks=seq(0,1000,by=250),limits=c(0,1000))+
  scale_y_continuous(breaks=seq(0.2,0.4,by=0.05),limits=c(0.2,0.4))
#ggsave("FigureS17.pdf",FigureS17,width = 20, height = 20, units = "cm", dpi = 300) 

