library(tidyverse)
library(ggtext)
library(ggdist)
library(geomtextpath)
library(glue)
library(patchwork)
library(rtry)
#setwd("C:\\Users\\lenovo\\Desktop")
library(ggplot2)
library(scales)

path=getwd()
setwd(path)
df=read.csv("statis_difference1放附表.csv")

title=c("1","4","9","16","100","400","900","1600")
p=list()
#average distance
variables=values=type=Percentage=NA
for (i in 1:8){
  df2=df[i,1:3]
  # 获取列名作为新列
  variables <- c(variables,names(df2))
  # 获取值作为新列
  values <- unlist(df2)
  type=c(type,rep(title[i],3))
  Percentage <- c(Percentage,values/ sum(values))
}
df3 <- data.frame(variable = variables,type=type,Percentage=100*Percentage)
df3 <- na.omit(df3)
df3$variable=ifelse(df3$variable == "avg_positive", "Convergent", 
                    ifelse(df3$variable == "avg_negative", "Divergent", 
                           ifelse(df3$variable =="avg_netural", "Neutral", df3$variable)))
df3$type=factor(df3$type, levels = title)
df3$type <- as.numeric(as.character(df3$type))
# write.csv(df3, "output_fileA.csv", row.names = FALSE)
rel_fre_avg=ggplot(df3,aes(y=Percentage, x = type, group=variable,color= variable, shape = variable)) +
  geom_line(size=1) +
  geom_point(size=5)+
  scale_x_log10()+
  annotation_logticks(sides = "b", short = unit(0.15, "cm"), mid = unit(0.2, "cm"),
                      long = unit(0.3, "cm"), size  = 1.0, outside = F) +
  labs(title = "Average distance", y = "Relative frequency (%)",x="", 
       color = "variable", shape = "variable") +
  annotate("text",x=0.72, y=79, label="a",angle = 0,size=15,family="sans")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x=element_text(size=25,family="serif",angle=0,colour = "black",vjust = 0.0),
        axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5,margin = margin(0,5,0,0)),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA),
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.text =element_text(size = 25,color='black'),
        legend.key.size = unit(2.5,'line'), # space between legend text
        legend.title = element_blank(),
        legend.position = c(0.81,0.85),
        legend.direction = "vertical",
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = 0.3, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm"))+
  scale_y_continuous(breaks=seq(0,80,by=20),limits=c(0,80))


#Total distance
variables=values=type=Percentage=NA
for (i in 1:8){
  df2=df[i,4:6]
  # 获取列名作为新列
  variables <- c(variables,names(df2))
  # 获取值作为新列
  values <- unlist(df2)
  type=c(type,rep(title[i],3))
  Percentage <- c(Percentage,values/ sum(values))
}
df3 <- data.frame(variable = variables,type=type,Percentage=100*Percentage)
df3 <- na.omit(df3)
df3$variable=ifelse(df3$variable == "tot_positive", "Convergent", 
                    ifelse(df3$variable == "tot_negative", "Divergent", 
                           ifelse(df3$variable =="tot_netural", "Neutral", df3$variable)))
df3$type=factor(df3$type,levels = title)
df3$type <- as.numeric(as.character(df3$type))
rel_fre_tot=ggplot(df3,aes(y=Percentage,x = type, group=variable,color= variable, shape = variable)) +
  geom_line(size=1) +
  geom_point(size=5)+
  scale_x_log10()+
  annotation_logticks(sides = "b", short = unit(0.15, "cm"), mid = unit(0.2, "cm"),
                      long = unit(0.3, "cm"), size  = 1.0, outside = F) +
  labs(title = "Total distance", y = "",x="",color = "variable", shape = "variable") +
  annotate("text",x=0.72, y=79, label="b",angle = 0,size=15,family="sans")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x=element_text(size=25,family="serif",angle=0,colour = "black",vjust = 0.0),
        axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5,margin = margin(0,5,0,0)),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        #axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA),
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.text =element_text(size = 25,color='black'),
        legend.key.size = unit(2.5,'line'), # space between legend text
        legend.title = element_blank(),
        legend.position = c(0.81,0.85),
        legend.direction = "vertical",
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = 0.3, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm"))+
  scale_y_continuous(breaks=seq(0,80,by=20),limits=c(0,80))

#median onset of flowering
variables=values=type=Percentage=NA
for (i in 1:8){
  df2=df[i,7:9]
  # 获取列名作为新列
  variables <- c(variables,names(df2))
  # 获取值作为新列
  values <- unlist(df2)
  type=c(type,rep(title[i],3))
  Percentage <- c(Percentage,values/ sum(values))
}
df3 <- data.frame(variable = variables,type=type,Percentage=100*Percentage)
df3 <- na.omit(df3)
df3$variable=ifelse(df3$variable == "flowert_positive", "Advance", 
                    ifelse(df3$variable == "flowert_negative", "Delay", 
                           ifelse(df3$variable =="flowert_netural", "Neutral", df3$variable)))
df3$type=factor(df3$type,levels = title)
df3$type <- as.numeric(as.character(df3$type))
rel_fre_median=ggplot(df3,aes(y=Percentage,x = type, group=variable,color= variable,shape = variable)) +
  geom_line(size=1) +
  geom_point(size=5)+
  scale_x_log10()+
  annotation_logticks(sides = "b", short = unit(0.15, "cm"), mid = unit(0.2, "cm"),
                      long = unit(0.3, "cm"), size  = 1.0, outside = F) +
  labs(title = "Median onset of flowering", y = "",x="Climate gradients",color = "variable", shape = "variable") +
  annotate("text",x=0.72, y=79, label="d",angle = 0,size=15,family="sans")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x=element_text(size=25,family="serif",angle=0,colour = "black",vjust = 0.0),
        axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5,margin = margin(0,5,0,0)),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA),
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.text =element_text(size = 25,color='black'),
        legend.key.size = unit(2.5,'line'), # space between legend text
        legend.title = element_blank(),
        legend.position = c(0.81,0.85),
        legend.direction = "vertical",
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = 0.3, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm"))+
  scale_y_continuous(breaks=seq(0,80,by=20),limits=c(0,80))


#number of minimum extremum
variables=values=type=Percentage=NA
for (i in 1:8){
  df2=df[i,10:12]
  # 获取列名作为新列
  variables <- c(variables,names(df2))
  # 获取值作为新列
  values <- unlist(df2)
  type=c(type,rep(title[i],3))
  Percentage <- c(Percentage,values/ sum(values))
}
df3 <- data.frame(variable = variables,type=type,Percentage=100*Percentage)
df3 <- na.omit(df3)
df3$variable=ifelse(df3$variable == "min_extre_positive", "Convergent", 
                    ifelse(df3$variable == "min_extre_negative", "Divergent", 
                           ifelse(df3$variable =="min_extre_netural", "Neutral", df3$variable)))
df3$type=factor(df3$type,levels = title)
df3$type <- as.numeric(as.character(df3$type))
rel_fre_minextr=ggplot(df3,aes(y=Percentage,x = type, group=variable,color= variable,shape = variable)) +
  geom_line(size=1) +
  geom_point(size=5)+
  scale_x_log10()+
  annotation_logticks(sides = "b", short = unit(0.15, "cm"), mid = unit(0.2, "cm"),
                      long = unit(0.3, "cm"), size  = 1.0, outside = F) +
  labs(title = "Number of minimum extremum", y = "Relative frequency (%)",x="Climate gradients",
       color = "variable", shape = "variable") +
  annotate("text",x=0.72, y=79, label="c",angle = 0,size=15,family="sans")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x=element_text(size=25,family="serif",angle=0,colour = "black",vjust = 0.0),
        axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5,margin = margin(0,5,0,0)),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA),
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.text =element_text(size = 25,color='black'),
        legend.key.size = unit(2.5,'line'), # space between legend text
        legend.title = element_blank(),
        legend.position = c(0.81,0.85),
        legend.direction = "vertical",
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = 0.3, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm"))+
  scale_y_continuous(breaks=seq(0,80,by=20),limits=c(0,80))

###############################################################

#
ggsave("relative frequency remote sensing2025_10_21.pdf",(rel_fre_avg|rel_fre_tot)/(rel_fre_minextr|rel_fre_median),width = 40, height = 40, units = "cm", dpi = 300) 


