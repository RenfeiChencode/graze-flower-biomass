library(scales)
library(tidyverse)
library(ggtext)
library(ggdist)
library(geomtextpath)
library(glue)
library(patchwork)
library(rtry)
library(glmmTMB)#generalise linear mixed model
library(MASS)
library(mclust)
library(ggplot2)
library(pracma)#
########################################
colors <- c("No grazing" = "#00BFC4", "Low grazing intensity" = "#7CAE00", "High grazing intensity" = "#F8766D")
#Fig1
df=read.csv("gr3.csv")
df$Grazed_f=ifelse(df$Grazed== 0, "No grazing", 
                  ifelse(df$Grazed== 1, "Low grazing intensity", 
                         ifelse(df$Grazed== 2, "High grazing intensity", df$Grazed)))
df$Grazed_f=factor(df$Grazed_f,levels = c("No grazing", "Low grazing intensity", "High grazing intensity")) #确保坐标轴显示顺序
df$Treatment=factor(df$Treatment..Name.of.the.experimental.treatment,levels = unique(df$Treatment..Name.of.the.experimental.treatment))
median_p <- median(df$Onsetflower, na.rm = TRUE)

# =======Figure 3a ==========
df_split <- df %>% split(.$Grazed_f)
peakT <- data.frame()
for (group_name in names(df_split)) {
  sub_df <- df_split[[group_name]]
  pdf_obj=density(sub_df$Onsetflower)
  peak_indices=findpeaks(pdf_obj$y, npeaks=5,minpeakheight  = 0.0015, minpeakdistance = 1,sortstr=TRUE)
  peak_values <- pdf_obj$x[peak_indices[,2]]
  peak_densities <- peak_indices[,1]
  peak_df=data.frame(peak_values=peak_values,peak_densities=peak_densities,Grazed_f=rep(group_name,length(peak_densities)))
  peakT=rbind(peakT,peak_df)
}
p_pooled=ggplot(df,aes(x = Onsetflower, fill = Grazed_f)) +
  geom_density(alpha=0.5)+    #Probability Density 
  #geom_histogram(aes(y = ..density..), binwidth = 0.5, fill = "skyblue", alpha = 0.7) + 
  geom_vline(data=peakT,aes(xintercept = peak_values, color = Grazed_f), linetype = "dashed",size=1.0)+
  facet_wrap(~ factor(Grazed_f,levels = c("No grazing", "Low grazing intensity", "High grazing intensity")), nrow = 1)+  
  labs(title="Pooled data",x="Onset of flowering (Julian day)",y="Probability density")+
  theme(strip.text = element_text(size = 25,vjust = 0.8),
        axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.text.x=element_text(size=25,family="serif",angle=0,colour = "black",vjust = 0.0),
        axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5,margin = margin(0,5,0,0)),
        axis.title.y=element_text(size=30,family="serif", angle=90, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.position = "none", 
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = 0.5, t = 0.4, l = 0,r=0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.2, b=0.2, l=0.12, "cm"))+
  scale_x_continuous(breaks=seq(0,300,by=70),limits=c(0,300))+
  scale_y_continuous(breaks=seq(0,0.015,by=0.005),limits=c(0,0.015))+
  scale_fill_manual(values = colors) +
  scale_color_manual(values = colors)
####
# =======Figure 3b ==========
sitename=unique(df$Location...Site.Name);p=list();distance_df=list()
sitename=sitename[c(-5,-7,-11)];
np=c(rep(3,6),2,4,3)
for (i in 1:9){
  df2=rtry_select_row(df,
                      (Location...Site.Name %in% sitename[i]),
                      getAncillary = TRUE)
  df3=data.frame(Onsetflower=df2$Onsetflower,Grazed=df2$Grazed)
  df3 <- na.omit(df3);df3$Grazed=ifelse(df3$Grazed == 0, "No grazing", 
                                        ifelse(df3$Grazed == 1, "Low grazing intensity",
                                               ifelse(df3$Grazed == 2, "High grazing intensity", df3$Grazed)))
  df_split <- df3 %>% split(.$Grazed)
  peakT <- data.frame();total_distance=average_distance=NA
  for (group_name in names(df_split)) {
    sub_df <- df_split[[group_name]]
    pdf_obj=density(sub_df$Onsetflower)
    peak_indices=findpeaks(pdf_obj$y, npeaks=np[i],minpeakheight  = 0.001, minpeakdistance = 1,sortstr=TRUE)
    peak_values <- pdf_obj$x[peak_indices[,2]]
    peak_densities <- peak_indices[,1]
    peak_df=data.frame(peak_values=peak_values,peak_densities=peak_densities,Grazed=rep(group_name,length(peak_densities)))
    peakT=rbind(peakT,peak_df)
    distance_matrix <- outer(peak_values, peak_values, function(ii, jj) abs(ii - jj))
    total_distance[group_name] <- sum(distance_matrix)
    num_pairs = length(peak_values)
    if(num_pairs>1){
      total_pairs = num_pairs * (num_pairs - 1)
      average_distance[group_name]=sum(distance_matrix)/total_pairs
    }else{
      average_distance[group_name]=sum(distance_matrix)
    }
  }
  distance_df[[i]]=data.frame(total_distance=round(na.omit(total_distance),3),average_distance=round(na.omit(average_distance),3),
                              Grazed=names(df_split),site=sitename[i])
  ran=range(df3$Onsetflower);xleft=floor(ran[1]);xright=ceiling(ran[2])
  step=(xright-xleft)/3;xm1=xleft+floor(step);xm2=xleft+floor(2*step)
  if(i==8){num_wrap=1}else{num_wrap=2}
  if(i==4){yright=0.12;ystep=0.04}else{yright=0.04;ystep=0.01}
  if(i==2|i==3|i==5|i==6|i==7|i==9){atey=atiy=element_blank();leftmargin=0}else{atey=element_text(size=25,family="serif",colour = "black")
  atiy=element_text(size=30,family="serif", angle=90, face="plain");leftmargin=0.12}
 
  p[[i]]= ggplot(df3,aes(x = Onsetflower, fill = Grazed)) +
    geom_density(alpha=0.5)+    #Probability Density  
    #geom_histogram(aes(y = ..density..), binwidth = 0.5, fill = "skyblue", alpha = 0.7) + 
    geom_vline(data=peakT,aes(xintercept = peak_values, color = Grazed), linetype = "dashed",size=1.0)+
    facet_wrap(~ factor(Grazed,levels=c("No grazing", "Low grazing intensity", "High grazing intensity")), 
               nrow = num_wrap)+  
    labs(title=paste("",sitename[i]),x="Onset of flowering (Julian day)",y="Probability density")+
    theme(strip.text = element_text(size = 25,vjust = 0.8),
          axis.text=element_text(size=25,family="serif",colour = "black"),
          axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
          axis.text.x=element_text(size=25,family="serif",angle=0,colour = "black",vjust = 0.0),
          axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.0,vjust = 0.5, 
                                   margin = margin(0,5,0,0)),
          axis.title.x = element_text(vjust=0.0),
          axis.line=element_line(size = 0.5, colour = "black", linetype=1),
          axis.ticks.length = unit(0.25, "cm"),
          axis.ticks = element_line(size = 1, color="black"),
          plot.background = element_rect(fill = "white", color = NA), 
          panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
          panel.background = element_rect(fill = "white", color = NA),
          legend.position = "none", 
          plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                    margin = margin(b = 0.5, t = 0.4, l = 0,r=0, unit = "cm")),
          plot.margin = margin(t=0.2, r=0.2, b=0.2, l=leftmargin, "cm"))+
    scale_x_continuous(breaks=c(xleft,xm1,xm2,xright),limits=c(xleft,xright))+
    scale_y_continuous(breaks=seq(0,yright,by=ystep),limits=c(0, yright))+
    scale_fill_manual(values = colors) +
    scale_color_manual(values = colors)
}
###############################################################
#ggsave("distribution total.pdf",pt,width = 20, height = 20, units = "cm", dpi = 300) 
#ggsave("distribution each site_part2.pdf",(p[[1]]|p[[2]]|p[[6]]|p[[4]])/(p[[5]]|p[[3]]|p[[9]]|p[[8]]),width = 60, height = 40, units = "cm", dpi = 300) 
#ggsave("site_IL_KDE.pdf",p[[7]],width = 60, height = 20, units = "cm", dpi = 300) 

#for (i in 1:9){
#  write.table(distance_df[[i]],
#file = 'distance each site.csv',sep = ",",row.names = FALSE, col.names = TRUE, append = TRUE)
#}
#write.csv(sitename,"sitename.csv")
#################################################################################################################################
########################################################
variables <- c("Both","Convergent","Neutral","Divergent")
values <- c(1/9,1/9,1/9,6/9)
df3 <- data.frame(
  variable = variables,
  value = values,
  stringsAsFactors = FALSE  
)
df3$Percentage <- df3$value / sum(df3$value)

# =======Figure 3c ==========
site_avg_tot=ggplot(df3, aes(x = "", y = value, fill = variable)) +
  labs(title = "Relative distance across sites")+
  geom_bar(stat = "identity", width = 1) +
  coord_polar("y", start = 0) +
  theme_void() + 
  geom_text(aes(label = ifelse(Percentage > 0, percent(Percentage), "")),  
            position = position_stack(vjust = 0.5), size=12)+
  theme(plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = 0.0, t = 0.4, l = 0,r=0, unit = "cm")),
        legend.text =element_text(size = 25,color='black'),
        legend.title=element_blank(),
        legend.direction = "horizontal",
        legend.key.size = unit(2.5,'line'), # space between legend text
        legend.spacing.x = unit(1.5, 'cm'),
        # legend.spacing.y = unit(2.5, 'cm'),
        #legend.margin = margin(t = 0, r = 10, b = 500, l = 10, unit = "pt"),
        legend.position = c(0.5, 0.0))+  
  guides(fill = guide_legend(nrow = 2)) 

OUTFIG=(p_pooled/p[[8]])|site_avg_tot#+ plot_layout(widths = c(2,2, 1), heights = c(1,1, 1))
#ggsave("Figure 33.pdf",OUTFIG,width = 75, height = 35, units = "cm", dpi = 600) 


