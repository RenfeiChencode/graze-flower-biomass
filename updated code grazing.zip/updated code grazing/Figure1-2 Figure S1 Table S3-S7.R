########################################
library(rtry)
library(patchwork)
library(MuMIn)
library(piecewiseSEM)#structure equation model
library(car)# for vif test
library(glmmTMB)#generalise linear mixed model
library(MASS)
library(ggplot2)
library(moments)#skewness and kurtosis
library(ppcor)#partial
########################################
#=======Table S3-S4=======
df=read.csv("gr3.csv")
skewness(df$AGBmax,na.rm =T);skewness(df$Onsetflower,na.rm =T)
kurtosis(df$AGBmax,na.rm =T);kurtosis(df$Onsetflower,na.rm =T)

fit <- glmmTMB(AGBmax~Grazed, data=df, family=t_family(link = "log"));summary(fit);length(na.omit(df$AGBmax))
fit <- glmmTMB(AGBmax~Grazed, data=df, family=gaussian(link = "log"));summary(fit)
fit <- glmmTMB(Onsetflower~Grazed, data=df, family=t_family(link = "log"));summary(fit);length(na.omit(df$Onsetflower))
fit <- glmmTMB(Onsetflower~Grazed, data=df, family=gaussian(link = "log"));summary(fit)
fit <- glmmTMB(AGBmax~Onsetflower, data=df, family=t_family(link = "log"));summary(fit)

df$Onsetflower_scaled <- scale(df$Onsetflower)#
fit <- glmmTMB(AGBmax~Onsetflower_scaled, data=df, family=t_family(link = "log"));summary(fit)
fit <- glmmTMB(AGBmax~Onsetflower_scaled, data=df, family=gaussian(link = "log"));summary(fit)

summary(lm(AGBmax~Onsetflower, data=df))
plot(df$Onsetflower,df$AGBmax)
########################################
#=======Table S5=======
df2=data.frame(Onsetflower=df$Onsetflower,Grazed=df$Grazed,carbon=df$Soil.C..carbon..content.per.soil.dry.mass,lat=df$Latitude,
               long=df$Longitude,light=df$Treatment.light,AGBmax=df$AGBmax,map=df$Mean.sum.of.annual.precipitation..PPT...MAP...TAP.,
               pet=df$Mean.annual.sum.of.potential.evapotranspiration..PET.,nitrogen=df$Soil.nitrogen.content.per.soil.dry.mass,
               phosphorus=df$Soil.P..phosphorus..content.total.per.soil.dry.mass,fertilization=df$Site.fertilization,
               WHC=df$Soil.water.holding.capacity..WHC.,altitude=df$Altitude,mat=df$Mean.annual.temperature..MAT.)
df2 <- na.omit(df2)
result2 <- pcor.test(x = df2$Grazed, y = df2$Onsetflower, z = df2[, c("carbon","light","map","pet","nitrogen","phosphorus","fertilization",
                                                                      "WHC","altitude","mat")], method = "spearman")
summary(result2)
print(result2$estimate)
print(result2$p.value)

result2 <- pcor.test(x = df2$Grazed, y = df2$AGBmax, z = df2[, c("carbon","light","map","pet","nitrogen","phosphorus","fertilization",
                                                                 "WHC","altitude","mat","Onsetflower")], method = "spearman")
summary(result2)
print(result2$estimate)
print(result2$p.value)
result2 <- pcor.test(y = df2$AGBmax, x =df2$Onsetflower , z = df2[, c("Grazed","carbon","light","map","pet","nitrogen","phosphorus","fertilization",
                                                                      "WHC","altitude","mat")], method = "pearson")
summary(result2)
print(result2$estimate)
print(result2$p.value)
########################################
#=======Table S6-S7=======
#structure equation model
df=read.csv("C:\\Users\\lenovo\\Desktop\\gr3.csv")#
df3=data.frame(Onsetflower=df$Onsetflower,Grazed=df$Grazed,carbon=df$Soil.C..carbon..content.per.soil.dry.mass,
               light=df$Treatment.light,map=df$Mean.sum.of.annual.precipitation..PPT...MAP...TAP.,AGBmax=df$AGBmax,
               pet=df$Mean.annual.sum.of.potential.evapotranspiration..PET.,nitrogen=df$Soil.nitrogen.content.per.soil.dry.mass,
               phosphorus=df$Soil.P..phosphorus..content.total.per.soil.dry.mass,fertilization=df$Site.fertilization,
               WHC=df$Soil.water.holding.capacity..WHC.,mat=df$Mean.annual.temperature..MAT.)
df3 <- na.omit(df3)
################
on3=vif(lm(Onsetflower~Grazed+map+fertilization+phosphorus+WHC+mat,data=df3))
ag3=vif(lm(AGBmax~Onsetflower+Grazed+map+fertilization+phosphorus+WHC+mat,data=df3))
on3=floor(on3*10)/10;ag3=floor(ag3*10)/10;
initial_model=psem(
  lm(Onsetflower~Grazed+WHC+map+mat,data=df3),
  lm(AGBmax~Grazed+fertilization+phosphorus+WHC+mat+map+Onsetflower,data=df3)
)
model_summary <- summary(initial_model)
fisherC(initial_model)

#=======Fig. S1=======
df=read.csv("gr3.csv");Lf3="Perennial";Fre3=length(na.omit(df$AGBmax))
df=read.csv("gr5.csv");Lf5="Annual";Fre5=length(na.omit(df$AGBmax))
df=read.csv("gr6.csv");Lf6="Biennial";Fre6=length(na.omit(df$AGBmax))
df4 <- data.frame(Category = c(Lf3,Lf5,Lf6),Value = c(Fre3, Fre5, Fre6))
PER3=Fre3/(Fre3+Fre5+ Fre6);PER5=Fre5/(Fre3+Fre5+ Fre6);PER6=Fre6/(Fre3+Fre5+ Fre6)
PER3=sprintf("%.2f%%", PER3 * 100)
PER5=sprintf("%.2f%%", PER5 * 100);PER6=sprintf("%.2f%%", PER6 * 100)

composition=ggplot(df4, aes(x = Category, y = Value)) + geom_bar(stat = "identity") +
  labs(title = "Species composition", x = "", y = "Frequency") +
annotate("text",x=3, y=1160, label=PER3,angle = 0,size=10,family="serif")+
  annotate("text",x=1, y=180, label=PER5,angle = 0,size=10,family="serif")+
  annotate("text",x=2, y=120, label=PER6,angle = 0,size=10,family="serif")+
  theme(axis.text=element_text(size=30,family="serif",colour = "black"),
        axis.text.x = element_text(vjust=0.0,size=20),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm")) +
  scale_y_continuous(breaks=seq(0,1200,by=300),limits=c(0,1200))
#ggsave("Species composition.pdf",composition,width = 20, height = 20, units = "cm", dpi = 300) 


#####
#=======Species composition in Figure 1c=======
df=read.csv("gr2.csv");compos=list()
sitename=unique(df$Location...Site.Name);lifesty=c("perennial" ,"annual" , "biennial" )

for (i in 1:12){
  df2=rtry_select_row(df,
                      (Location...Site.Name %in% sitename[i]),
                      getAncillary = TRUE)
  
  perennial_df=rtry_select_row(df2,
                      (lifehistory %in% lifesty[1]),
                      getAncillary = TRUE)
  annual_df=rtry_select_row(df2,
                               (lifehistory %in% lifesty[2]),
                               getAncillary = TRUE)
  biennial_df=rtry_select_row(df2,
                               (lifehistory %in% lifesty[3]),
                               getAncillary = TRUE)
  
  
  Fre_perennial=length(na.omit(perennial_df$Onsetflower))
  Fre_annual=length(na.omit(annual_df$Onsetflower))
  Fre_biennial=length(na.omit(biennial_df$Onsetflower))
  
  tot=Fre_perennial+Fre_annual+Fre_biennial
  
  
  df5 <- data.frame(Category = lifesty,Value = c(Fre_perennial/tot,Fre_annual/tot,Fre_biennial/tot))
  df5$Category=factor(df5$Category,levels = lifesty)
  labba=sprintf("%.2f%%", df5$Value * 100)

  compos[[i]]=ggplot(df5, aes(x = "", y = Value,fill=Category)) + geom_bar(stat = "identity",width = 1) +
    coord_polar("y", start = 0) +
    theme_void() + 
    geom_text(aes(label = ifelse(Value > 0, percent(Value), "")),  
               position = position_stack(vjust = 0.5),color="white")+
    labs(title = sitename[i])+
    scale_fill_manual(values=c("orange","blue","red"))
}
#ggsave("Species composition each site2.pdf",(compos[[1]]|compos[[2]]|compos[[3]])/
#         (compos[[4]]|compos[[5]]|compos[[6]])/(compos[[7]]|compos[[8]]|compos[[9]])/(compos[[10]]|compos[[11]]|compos[[12]]),
#       width = 60, height = 80, units = "cm", dpi = 300) 
