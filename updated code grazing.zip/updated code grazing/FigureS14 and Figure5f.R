library(ggplot2);library(gridExtra);library(scales);library(grid)
library(sqldf);library(dplyr);library(patchwork);library(ggsignif)
library(PSPManalysis)
library(latex2exp)
library(shape)
library(igraph)
library(DescTools)
####################################################################
ToPdf <- T
EBT_PSPM_cmp <- F
#1 nursery; 2 grazed area; 3 protected area
EBTtcol         <-  1
EBTres1col      <-  2
EBTres2col      <-  3
EBTres3col      <-  4
EBTtotnumcol    <-  5
EBTtotbiocol    <-  6
EBTh1numcol     <-  7
EBTh1biocol     <-  8
EBTh2numcol     <-  9
EBTh2biocol     <- 10
EBTh3numcol     <- 11
EBTh3biocol     <- 12
EBTh2juvnumcol  <- 13
EBTh2juvbiocol  <- 14
EBTh3juvnumcol  <- 15
EBTh3juvbiocol  <- 16
EBTh2adunumcol  <- 17
EBTh2adubiocol  <- 18
EBTh3adunumcol  <- 19
EBTh3adubiocol  <- 20
EBTsmoltsizecol <- 21   
EBTtotreprocol  <- 22
EBTnumcohcol    <- 23
EBTyieldjuv     <- 24
EBTyieldadu     <- 25
EBTyieldtot     <- 26
EBTbifparcol    <- 27
EBTperiodcol    <- 28

PSPMbifparcol    <-  1
PSPMres1col      <-  2
PSPMres2col      <-  3
PSPMres3col      <-  4
PSPMh1biocol     <-  9
PSPMh2juvbiocol  <- 10
PSPMh3juvbiocol  <- 11
PSPMh2adubiocol  <- 12
PSPMh3adubiocol  <- 13
PSPMh1numcol     <- 14
PSPMh2numcol     <- 15
PSPMh3numcol     <- 16

iArrows <- igraph:::igraph.Arrows
DefaultPars <- c(Rho1 = 0.5, Rho2 =    0.5, Delta = 1.0, 
                 Eta1 = 1.0, Eta2 =    0.8, Eta3  = 0.8, 
                 ETSJ = 1.4, ETSA =    1.4, WS    = 0.35, 
                 Q    = 1.0, Beta = 2000.0, SR    = 0.0)

if (ToPdf) pdf(file = fname, width = (34.0 / 2.54), height = 10.0)
layout(matrix(1:1, nrow = 1, ncol = 1), widths = c(1.0, rep(1.0, 1)), heights = rep(c(0.98, 1.3), 1))
xlimc <- c(-0.0, 1.0)
xlimw <- c(0.05, 0.45)
ylim1 <- c(-0.05, 1.05)
ylim2 <- c(-0.02, 0.4)

cexlab <- 2.0
cexaxs <- 2.0
cexleg <- 1.8
cexttl <- 2.2
cexpnt <- 2.0
cexbt  <- 1.6

axislwd <- 3

par(tcl = 0.6, mgp = c(3, 1, 0))
lwd=2
init=c(0.05, 0.9142577824,	0.2843496419,	0.1620576624, 1)#######
pars <- DefaultPars
pars["SR"] <- 0.25
if (!exists("Equi_SR03_Ws")) {
  Equi_SR03_Ws <- PSPMequi(modelname = paste0(modeldir, "grazeWithReserve"), 
                           biftype = "EQ", startpoint = init, 
                           stepsize = 0.01, parbnds = c(8, 0.05, 0.5), 
                           parameters = pars, clean=TRUE, 
                           options = c("popEVO", "0"))
}

dt          <- Equi_SR03_Ws$curvepoints
dtbp        <- Equi_SR03_Ws$bifpoints
dtbt        <- Equi_SR03_Ws$biftypes

EBTdt       <- read.table(paste0(datadir, "figS14minmax.out"))
EBTmax      <- EBTdt[2 * (1:(nrow(EBTdt) / 2.0)),]
EBTmin      <- EBTdt[2 * (1:(nrow(EBTdt) / 2.0)) - 1,]

stable      <- EBTmax[, EBTperiodcol] > 1.0E-4
indx2       <- nrow(EBTmax)
indx1       <- max((1:indx2)[stable]) + 1
EBTdwnM     <- rbind(EBTmax[(1:indx1),], EBTmin[(indx1:1),])
stable      <- dt[, PSPMbifparcol] < min(EBTdwnM[, EBTbifparcol])

par(mar = c(6, 10, 4.0, 2.5))
indx1 <- which.min(abs(dt[,PSPMbifparcol] - dtbp[1,PSPMbifparcol]))
indx2 <- which.min(abs(dt[,PSPMbifparcol] - dtbp[3,PSPMbifparcol]))
indx3 <- max((indx2:nrow(dt))[dt[(indx2:nrow(dt)),PSPMbifparcol] < min(EBTdwnM[,EBTbifparcol])])

plot(NULL, NULL, xlim = xlimw, ylim = ylim2, 
     xlab = "", ylab = "", xaxs = "i", yaxs = "i",
     xaxt = "n", yaxt = "n")
axis(1, at = 0.05 + (0:4) * 0.1, label = c("0.05", "0.15", "0.25", "0.35","0.45"), 
     cex.axis = cexaxs, lwd = 2, lwd.ticks = axislwd)
axis(2, at = (0:4) * 0.1, label = c("0.0", "0.1", "0.2", "0.3", "0.4"), 
     cex.axis = cexaxs, lwd = 2, lwd.ticks = axislwd, las = 2)
mtext("Biomass (equilibrium)", 2, cex = cexlab, line = 4.8)
mtext("Onset of flowering", 1, cex = cexlab, line = 4.5)
mtext("b: 75% grazed", 3, cex = cexttl, line = 1.0)

lines(dt[(1:indx1),PSPMbifparcol], dt[(1:indx1),PSPMh2juvbiocol] + dt[(1:indx1),PSPMh2adubiocol], lwd = 2 * lwd, col = "red")
lines(dt[(indx1:indx2),PSPMbifparcol], dt[(indx1:indx2),PSPMh2juvbiocol] + dt[(indx1:indx2),PSPMh2adubiocol], lwd = lwd, lty = 3, col = "black")
lines(dt[(indx2:indx3),PSPMbifparcol], dt[(indx2:indx3),PSPMh2juvbiocol] + dt[(indx2:indx3),PSPMh2adubiocol], lwd = 2 * lwd, col = "red")
lines(dt[(indx3:nrow(dt)),PSPMbifparcol], dt[(indx3:nrow(dt)),PSPMh2juvbiocol] + dt[(indx3:nrow(dt)),PSPMh2adubiocol], lwd = lwd, col = "black", lty = 2)

lines(EBTdwnM[,EBTbifparcol], EBTdwnM[,EBTh2biocol], lwd = lwd, col = "orange")
points(dtbp[1,PSPMbifparcol],dtbp[1,PSPMh2juvbiocol] + dtbp[1,PSPMh2adubiocol], pch = 19, col = "red", cex = cexpnt)
points(dtbp[3,PSPMbifparcol], dtbp[3,PSPMh2juvbiocol] + dtbp[3,PSPMh2adubiocol], pch = 19, col = "red", cex = cexpnt)

Arrows(0.09, 0.09, 0.16, 0.09, arr.type="triangle", lwd = 5, arr.width = 0.2, col = "black")
Arrows(0.44, 0.35, 0.37, 0.35, arr.type="triangle", lwd = 5, arr.width = 0.2, col = "black")
legend("topleft", legend = c("Stable", "Unstable","Minimum / maximum"), col = c("red","black","orange"), lty = c(1,2,1), cex = cexbt,lwd = c(4,2,2))

if (ToPdf) {
  dev.off()
  system(paste("open ", fname))
}
