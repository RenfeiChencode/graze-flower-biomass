library(ggplot2)
library(patchwork)

NoEvoJ0A15=read.table("NoEvoJ0A15.out")
NoEvoJ15A0=read.table("NoEvoJ15A0.out")
EvoJ0A15=read.table("EvoJ0A15.out")
EvoJ15A0=read.table("EvoJ15A0.out")

NoEvoJ0A15=NoEvoJ0A15[12:200,]
NoEvoJ15A0=NoEvoJ15A0[12:200,]
EvoJ0A15=EvoJ0A15[12:2000,]
EvoJ15A0=EvoJ15A0[12:2000,]

#h1 nursery; h2 grazed area; h3 inside protected area
tcol         <-  1
res1col      <-  2
res2col      <-  3
res3col      <-  4
totnumcol    <-  5
totbiocol    <-  6
h1numcol     <-  7
h1biocol     <-  8
h2numcol     <-  9
h2biocol     <- 10
h3numcol     <- 11
h3biocol     <- 12
h2juvnumcol  <- 13
h2juvbiocol  <- 14
h3juvnumcol  <- 15
h3juvbiocol  <- 16
h2adunumcol  <- 17
h2adubiocol  <- 18
h3adunumcol  <- 19
h3adubiocol  <- 20
smoltsizecol <- 21   
totreprocol  <- 22
numcohcol    <- 23
yieldjuvcol  <- 24
yieldaducol  <- 25
yieldtotcol  <- 26
#============Figure S12-S13==============
#############################################################
class1=rep("Total in grazed area",length(NoEvoJ0A15[,10]))
class2=rep("Small in grazed area",length(NoEvoJ0A15[,14]))
class3=rep("Large in grazed area",length(NoEvoJ0A15[,18]))
df=data.frame(time=rep(NoEvoJ0A15[,1],3),bio=c(NoEvoJ0A15[,10],NoEvoJ0A15[,14],NoEvoJ0A15[,18]),
              class=c(class1,class2,class3))
figS1p1=ggplot(df,aes(x=time,y=bio,color=class))+geom_line()+theme_classic()+
  theme(text = element_text(size = 18), 
        axis.text.x = element_text(size = 18), 
        plot.title = element_text(hjust = 0.5), 
        legend.position = "none")+
  ggtitle("Herbivore foraging large \n Constant onset of flowering") + 
  annotate("text",x=0.0, y=0.8, label="a",colour="black",angle = 0,size=10,family="serif")+
  xlab("Time") +  ylab("Biomass")+
  scale_x_continuous(breaks=seq(0.0,100,by=25),limits=c(0.0,100))+
  scale_y_continuous(breaks=seq(0.0,0.8,by=0.2),limits=c(0.0,0.8))

class1=rep("Total in grazed area",length(NoEvoJ15A0[,10]))
class2=rep("Small in grazed area",length(NoEvoJ15A0[,14]))
class3=rep("Large in grazed area",length(NoEvoJ15A0[,18]))
df=data.frame(time=rep(NoEvoJ15A0[,1],3),bio=c(NoEvoJ15A0[,10],NoEvoJ15A0[,14],NoEvoJ15A0[,18]),
              class=c(class1,class2,class3))
figS1p2=ggplot(df,aes(x=time,y=bio,color=class))+geom_line(size=1)+theme_classic()+
  theme(text = element_text(size = 18), 
        axis.text.x = element_text(size = 18), 
        plot.title = element_text(hjust = 0.5), 
        legend.position = c(0.5,0.75),
        legend.title = element_blank())+
  ggtitle("Herbivore foraging small \n Constant onset of flowering") + 
  annotate("text",x=0.0, y=0.8, label="b",colour="black",angle = 0,size=10,family="serif")+
  xlab("Time") +  ylab("Biomass")+
  scale_x_continuous(breaks=seq(0.0,100,by=25),limits=c(0.0,100))+
  scale_y_continuous(breaks=seq(0.0,0.8,by=0.2),limits=c(0.0,0.8))

#############################################################
class1=rep("Total in protected area",length(NoEvoJ0A15[,12]))
class2=rep("Small in protected area",length(NoEvoJ0A15[,16]))
class3=rep("Large in protected area",length(NoEvoJ0A15[,20]))
df=data.frame(time=rep(NoEvoJ0A15[,1],3),bio=c(NoEvoJ0A15[,12],NoEvoJ0A15[,16],NoEvoJ0A15[,20]),
              class=c(class1,class2,class3))
figS2p1=ggplot(df,aes(x=time,y=bio,color=class))+geom_line()+theme_classic()+
  theme(text = element_text(size = 18), 
        axis.text.x = element_text(size = 18), 
        plot.title = element_text(hjust = 0.5), 
        legend.position = "none")+
  ggtitle("Herbivore foraging large \n Constant onset of flowering") + 
  annotate("text",x=0.0, y=0.8, label="a",colour="black",angle = 0,size=10,family="serif")+
  xlab("Time") +  ylab("Biomass")+
  scale_x_continuous(breaks=seq(0.0,100,by=25),limits=c(0.0,100))+
  scale_y_continuous(breaks=seq(0.0,0.8,by=0.2),limits=c(0.0,0.8))

class1=rep("Total in protected area",length(NoEvoJ15A0[,12]))
class2=rep("Small in protected area",length(NoEvoJ15A0[,16]))
class3=rep("Large in protected area",length(NoEvoJ15A0[,20]))
df=data.frame(time=rep(NoEvoJ15A0[,1],3),bio=c(NoEvoJ15A0[,12],NoEvoJ15A0[,16],NoEvoJ15A0[,20]),
              class=c(class1,class2,class3))
figS2p2=ggplot(df,aes(x=time,y=bio,color=class))+geom_line(size=1)+theme_classic()+
  theme(text = element_text(size = 18), 
        axis.text.x = element_text(size = 18), 
        plot.title = element_text(hjust = 0.5), 
        legend.position = c(0.5,0.85),
        legend.title = element_blank())+
  ggtitle("Herbivore foraging small \n Constant onset of flowering") + 
  annotate("text",x=0.0, y=0.8, label="b",colour="black",angle = 0,size=10,family="serif")+
  xlab("Time") +  ylab("Biomass")+
  scale_x_continuous(breaks=seq(0.0,100,by=25),limits=c(0.0,100))+
  scale_y_continuous(breaks=seq(0.0,0.8,by=0.2),limits=c(0.0,0.8))


#############################################################
# Varied onset of flowering
class1=rep("Total in protected area",length(EvoJ0A15[,12]))
class2=rep("Small in protected area",length(EvoJ0A15[,16]))
class3=rep("Large in protected area",length(EvoJ0A15[,20]))
df=data.frame(time=rep(EvoJ0A15[,1],3),bio=c(EvoJ0A15[,12],EvoJ0A15[,16],EvoJ0A15[,20]),
              class=c(class1,class2,class3))
figS3p1=ggplot(df,aes(x=time,y=bio,color=class))+geom_line()+theme_classic()+
  theme(text = element_text(size = 18), 
        axis.text.x = element_text(size = 18), 
        plot.title = element_text(hjust = 0.5), 
        legend.position = "none")+
  ggtitle("Varied onset of flowering") + 
  annotate("text",x=0.0, y=0.8, label="c",colour="black",angle = 0,size=10,family="serif")+
  xlab("Time") +  ylab("Biomass")+
  scale_x_continuous(breaks=seq(0.0,1000,by=250),limits=c(0.0,1000))+
  scale_y_continuous(breaks=seq(0.0,0.8,by=0.2),limits=c(0.0,0.8))

class1=rep("Total in protected area",length(EvoJ15A0[,12]))
class2=rep("Small in protected area",length(EvoJ15A0[,16]))
class3=rep("Large in protected area",length(EvoJ15A0[,20]))
df=data.frame(time=rep(EvoJ15A0[,1],3),bio=c(EvoJ15A0[,12],EvoJ15A0[,16],EvoJ15A0[,20]),
              class=c(class1,class2,class3))
figS3p2=ggplot(df,aes(x=time,y=bio,color=class))+geom_line(size=1)+theme_classic()+
  theme(text = element_text(size = 18), 
        axis.text.x = element_text(size = 18), 
        plot.title = element_text(hjust = 0.5), 
        legend.position = "none",
        legend.title = element_blank())+
  ggtitle("Varied onset of flowering") + 
  annotate("text",x=0.0, y=0.8, label="d",colour="black",angle = 0,size=10,family="serif")+
  xlab("Time") +  ylab("Biomass")+
  scale_x_continuous(breaks=seq(0.0,1000,by=250),limits=c(0.0,1000))+
  scale_y_continuous(breaks=seq(0.0,0.8,by=0.2),limits=c(0.0,0.8))


class1=rep("Total in grazed area",length(EvoJ0A15[,10]))
class2=rep("Small in grazed area",length(EvoJ0A15[,14]))
class3=rep("Large in grazed area",length(EvoJ0A15[,18]))
df=data.frame(time=rep(EvoJ0A15[,1],3),bio=c(EvoJ0A15[,10],EvoJ0A15[,14],EvoJ0A15[,18]),
              class=c(class1,class2,class3))
figS4p1=ggplot(df,aes(x=time,y=bio,color=class))+geom_line()+theme_classic()+
  theme(text = element_text(size = 18), 
        axis.text.x = element_text(size = 18), 
        plot.title = element_text(hjust = 0.5), 
        legend.position = "none")+
  ggtitle("Varied onset of flowering") + 
  xlab("Time") +  ylab("Biomass")+
  annotate("text",x=0.0, y=0.8, label="c",colour="black",angle = 0,size=10,family="serif")+
  scale_x_continuous(breaks=seq(0.0,1000,by=250),limits=c(0.0,1000))+
  scale_y_continuous(breaks=seq(0.0,0.8,by=0.2),limits=c(0.0,0.8))

class1=rep("Total in grazed area",length(EvoJ15A0[,10]))
class2=rep("Small in grazed area",length(EvoJ15A0[,14]))
class3=rep("Large in grazed area",length(EvoJ15A0[,18]))
df=data.frame(time=rep(EvoJ15A0[,1],3),bio=c(EvoJ15A0[,10],EvoJ15A0[,14],EvoJ15A0[,18]),
              class=c(class1,class2,class3))
figS4p2=ggplot(df,aes(x=time,y=bio,color=class))+geom_line(size=1)+theme_classic()+
  theme(text = element_text(size = 18), 
        axis.text.x = element_text(size = 18), 
        plot.title = element_text(hjust = 0.5), 
        legend.position = "none",
        legend.title = element_blank())+
  ggtitle("Varied onset of flowering") + 
  xlab("Time") +  ylab("Biomass")+
  annotate("text",x=0.0, y=0.8, label="d",colour="black",angle = 0,size=10,family="serif")+
  scale_x_continuous(breaks=seq(0.0,1000,by=250),limits=c(0.0,1000))+
  scale_y_continuous(breaks=seq(0.0,0.8,by=0.2),limits=c(0.0,0.8))

#ggsave("grazed_area_bio.pdf",(figS1p1|figS1p2)/(figS4p1|figS4p2),width = 30, height = 25, units = "cm", dpi = 300)
#ggsave("protected_area_bio.pdf",(figS2p1|figS2p2)/(figS3p1|figS3p2),width = 30, height = 25, units = "cm", dpi = 300)
