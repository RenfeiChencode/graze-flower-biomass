library(ggplot2);library(gridExtra);library(scales);library(grid)
library(sqldf);library(dplyr);library(patchwork);library(ggsignif)
####################################################################
c025noevo=read.table("figS10S11c025noevo14.out")
c005noevo=read.table("figS10S11c005noevo14.out")
c025evo=read.table("figS10S11c025evo14.out")
c005evo=read.table("figS10S11c005evo14.out")
tcol         <-  1
res1col      <-  2
res2col      <-  3
res3col      <-  4
totnumcol    <-  5
totbiocol    <-  6
h1numcol     <-  7
h1biocol     <-  8
h2numcol     <-  9
h2biocol     <- 10
h3numcol     <- 11
h3biocol     <- 12
h2juvnumcol  <- 13
h2juvbiocol  <- 14
h3juvnumcol  <- 15
h3juvbiocol  <- 16
h2adunumcol  <- 17
h2adubiocol  <- 18
h3adunumcol  <- 19
h3adubiocol  <- 20
smoltsizecol <- 21   
totreprocol  <- 22
numcohcol    <- 23
yieldjuvcol  <- 24
yieldaducol  <- 25
yieldtotcol  <- 26

NN=length(c025noevo[,tcol])
numnoevo=c(c025noevo[500:NN,h3numcol],c025noevo[500:NN,h2numcol])
bionoevo=c(c025noevo[500:NN,h3biocol],c025noevo[500:NN,h2biocol])

class=c(rep("Protected area",NN-499),rep("Grazed area",NN-499))
time=rep((c025noevo[500:NN,tcol]-500),2)
dfnoevo=data.frame(numnoevo=numnoevo,bionoevo=bionoevo,class=class,time=time)

NN=length(c025evo[,tcol])
numevo=c(c025evo[500:NN,h3numcol],c025evo[500:NN,h2numcol])
bioevo=c(c025evo[500:NN,h3biocol],c025evo[500:NN,h2biocol])
class=c(rep("Protected area",NN-499),rep("Grazed area",NN-499))
time=rep((c025evo[500:NN,tcol]-500),2)
dfevo=data.frame(numevo=numevo,bioevo=bioevo,class=class,time=time)


FigureS11A=ggplot(data = dfnoevo,aes(x=time,y=bionoevo,group=class,color=class))+geom_path(size=1)+
  #geom_vline(xintercept=500,colour="grey",lty="dashed",size=2)+
  #annotate("text",x=460, y=0.2, label="Protection start",colour="grey",angle = 90,size=10,family="serif")+
  annotate("text",x=1, y=0.37, label="a",angle = 0,size=10,family="serif")+
  labs(title="Constant onset of flowering",colour="",x="Time",y="Biomass")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x = element_text(vjust=0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        line = element_blank(),
        legend.key = element_blank(),
        legend.position = c(0.75,0.9), 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 20,color='black'),
        legend.title = element_text(size=25, face = "bold"),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm") )+
  scale_x_continuous(breaks=seq(0,1000,by=250),limits=c(0,1000))+
  scale_y_continuous(breaks=seq(0,0.4,by=0.1),limits=c(0,0.4))

FigureS11B=ggplot(data = dfevo,aes(x=time,y=bioevo,group=class,color=class))+geom_path(size=1)+
  #geom_vline(xintercept=500,colour="grey",lty="dashed",size=2)+
  #annotate("text",x=390, y=0.2, label="Protection start",colour="grey",angle = 90,size=10 ,family="serif")+
  annotate("text",x=1, y=0.38, label="b",angle = 0,size=10,family="serif")+
  labs(title="Varied onset of flowering",colour="",x="Time",y="Biomass")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x = element_text(vjust=0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        line = element_blank(),
        legend.key = element_blank(),
        legend.position = "none", 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 16,color='black'),
        legend.title = element_text(size=16, face = "bold"),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm") )+
  scale_x_continuous(breaks=seq(0,1000,by=250),limits=c(0,1000))+
  scale_y_continuous(breaks=seq(0,0.4,by=0.1),limits=c(0,0.4))


FigureS11C=ggplot(data = dfnoevo,aes(x=time,y=numnoevo,group=class,color=class))+geom_path(size=1)+
  #geom_vline(xintercept=500,colour="grey",lty="dashed",size=2)+
  #annotate("text",x=460, y=0.5, label="Protection start",colour="grey",angle = 90,size=10,family="serif" )+
  annotate("text",x=1, y=0.98, label="c",angle = 0,size=10,family="serif")+
  labs(title="Constant onset of flowering",colour="",x="Time",y="Number")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x = element_text(vjust=0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        line = element_blank(),
        legend.key = element_blank(),
        legend.position = "none", 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 16,color='black'),
        legend.title = element_text(size=16, face = "bold"),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm") )+
  scale_x_continuous(breaks=seq(0,1000,by=250),limits=c(0,1000))+
  scale_y_continuous(breaks=seq(0,1,by=0.25),limits=c(0,1))


FigureS11D=ggplot(data = dfevo,aes(x=time,y=numevo,group=class,color=class))+geom_path(size=1)+
  #geom_vline(xintercept=500,colour="grey",lty="dashed",size=2)+
  #annotate("text",x=390, y=0.5, label="Protection start",colour="grey",angle = 90,size=10,family="serif")+
  annotate("text",x=1, y=0.98, label="d",angle = 0,size=10,family="serif")+
  labs(title="Varied onset of flowering",colour="",x="Time",y="Number")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x = element_text(vjust=0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        line = element_blank(),
        legend.key = element_blank(),
        legend.position = "none", 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 16,color='black'),
        legend.title = element_text(size=16, face = "bold"),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm") )+
  scale_x_continuous(breaks=seq(0,1000,by=250),limits=c(0,1000))+
  scale_y_continuous(breaks=seq(0,1,by=0.25),limits=c(0,1))

(FigureS11A|FigureS11B)/(FigureS11C|FigureS11D)
#####################################
#figure S10 onset of flowering vs time
NN=length(c025noevo[,tcol])
WSnoevo=c025noevo[500:NN,smoltsizecol]

class=rep("75% grazed",NN-499)
time=c025noevo[500:NN,tcol]-500
dfnoevo=data.frame(WSnoevo=WSnoevo,class=class,time=time)

NN=length(c025evo[,tcol])
class=rep("75% grazed",NN-499)
time=c025evo[500:NN,tcol]-500
WSevo=c025evo[500:NN,smoltsizecol]
dfevo=data.frame(WSevo=WSevo,class=class,time=time)

FigureS10A=ggplot(data = dfnoevo,aes(x=time,y=WSnoevo,group=class,color=class))+geom_path(size=1)+
  #geom_vline(xintercept=500,colour="grey",lty="dashed",size=2)+
  #annotate("text",x=440, y=0.28, label="Protection start",colour="grey",angle = 90,size=10,family="serif")+
  annotate("text",x=1, y=0.38, label="a",angle = 0,size=10,family="serif")+
  labs(title="No evolution",colour="",x="Time",y="Onset of flowering")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x = element_text(vjust=0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        line = element_blank(),
        legend.key = element_blank(),
        legend.position ="none", 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 20,color='black'),
        legend.title = element_text(size=25, face = "bold"),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm") )+
  scale_x_continuous(breaks=seq(0,1000,by=250),limits=c(0,1000))+
  scale_y_continuous(breaks=seq(0.2,0.4,by=0.05),limits=c(0.2,0.4))

FigureS10B=ggplot(data = dfevo,aes(x=time,y=WSevo,group=class,color=class))+geom_path(size=1)+
  #geom_vline(xintercept=500,colour="grey",lty="dashed",size=2)+
  #annotate("text",x=360, y=0.27, label="Protection start",colour="grey",angle = 90,size=10 ,family="serif")+
  annotate("text",x=1, y=0.38, label="b",angle = 0,size=10,family="serif")+
  labs(title="Evolution",colour="",x="Time",y="Onset of flowering")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x = element_text(vjust=0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        line = element_blank(),
        legend.key = element_blank(),
        legend.position = "none", 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 20,color='black'),
        legend.title = element_text(size=25, face = "bold"),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm") )+
  scale_x_continuous(breaks=seq(0,1000,by=250),limits=c(0,1000))+
  scale_y_continuous(breaks=seq(0.2,0.4,by=0.05),limits=c(0.2,0.4))

####################################
#biomass and number in ontogenetic stage 1
NN=length(c025noevo[,tcol])
numnoevo=c025noevo[500:NN,h1numcol]
bionoevo=c025noevo[500:NN,h1biocol]
time=(c025noevo[500:NN,tcol]-500)
dfnoevo=data.frame(numnoevo=numnoevo,bionoevo=bionoevo,time=time)

NN=length(c025evo[,tcol])
numevo=c025evo[500:NN,h1numcol]
bioevo=c025evo[500:NN,h1biocol]
time=(c025evo[500:NN,tcol]-500)
dfevo=data.frame(numevo=numevo,bioevo=bioevo,time=time)

FigureS10C=ggplot(data = dfnoevo,aes(x=time,y=bionoevo))+geom_path(size=1)+
  #geom_vline(xintercept=500,colour="grey",lty="dashed",size=2)+
  #annotate("text",x=460, y=0.2, label="Protection start",colour="grey",angle = 90,size=10,family="serif")+
  annotate("text",x=1, y=1.13, label="c",angle = 0,size=10,family="serif")+
  labs(title="Constant onset of flowering",colour="",x="Time",y="Biomass")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x = element_text(vjust=0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        line = element_blank(),
        legend.key = element_blank(),
        legend.position = "none", 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 20,color='black'),
        legend.title = element_text(size=16, face = "bold"),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm") )+
  scale_x_continuous(breaks=seq(0,1000,by=250),limits=c(0,1000))+
  scale_y_continuous(breaks=seq(0,1.2,by=0.3),limits=c(0,1.2))

FigureS10D=ggplot(data = dfevo,aes(x=time,y=bioevo))+geom_path(size=1)+
  #geom_vline(xintercept=500,colour="grey",lty="dashed",size=2)+
  #annotate("text",x=390, y=0.2, label="Protection start",colour="grey",angle = 90,size=10 ,family="serif")+
  annotate("text",x=1, y=1.13, label="d",angle = 0,size=10,family="serif")+
  labs(title="Varied onset of flowering",colour="",x="Time",y="Biomass")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x = element_text(vjust=0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        line = element_blank(),
        legend.key = element_blank(),
        legend.position = "none", 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 16,color='black'),
        legend.title = element_text(size=16, face = "bold"),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm") )+
  scale_x_continuous(breaks=seq(0,1000,by=250),limits=c(0,1000))+
  scale_y_continuous(breaks=seq(0,1.2,by=0.3),limits=c(0,1.2))


FigureS10E=ggplot(data = dfnoevo,aes(x=time,y=numnoevo,group=class,color=class))+geom_path(size=1)+
  #geom_vline(xintercept=500,colour="grey",lty="dashed",size=2)+
  #annotate("text",x=460, y=0.5, label="Protection start",colour="grey",angle = 90,size=10,family="serif" )+
  annotate("text",x=1, y=38, label="e",angle = 0,size=10,family="serif")+
  labs(title="Constant onset of flowering",colour="",x="Time",y="Number")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x = element_text(vjust=0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        line = element_blank(),
        legend.key = element_blank(),
        legend.position = "none", 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 16,color='black'),
        legend.title = element_text(size=16, face = "bold"),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm") )+
  scale_x_continuous(breaks=seq(0,1000,by=250),limits=c(0,1000))+
  scale_y_continuous(breaks=seq(0,40,by=10),limits=c(0,40))


FigureS10F=ggplot(data = dfevo,aes(x=time,y=numevo,group=class,color=class))+geom_path(size=1)+
  #geom_vline(xintercept=500,colour="grey",lty="dashed",size=2)+
  #annotate("text",x=390, y=0.5, label="Protection start",colour="grey",angle = 90,size=10,family="serif")+
  annotate("text",x=1, y=38, label="f",angle = 0,size=10,family="serif")+
  labs(title="Varied onset of flowering",colour="",x="Time",y="Number")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x = element_text(vjust=0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        line = element_blank(),
        legend.key = element_blank(),
        legend.position = "none", 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 16,color='black'),
        legend.title = element_text(size=16, face = "bold"),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm") )+
  scale_x_continuous(breaks=seq(0,1000,by=250),limits=c(0,1000))+
  scale_y_continuous(breaks=seq(0,40,by=10),limits=c(0,40))

####################################
#ggsave("Effect of flowering on biomass and number2025_9_20.pdf",grid.arrange(FigureS11A,FigureS11B,FigureS11C,FigureS11D,ncol=2,nrow=2),width = 40, height = 30, units = "cm", dpi = 300) 
#ggsave("flowering vs. time bio num stage1_2025_9_20.pdf",grid.arrange(FigureS10A,FigureS10B,FigureS10C,FigureS10D,FigureS10E,FigureS10F,ncol=2,nrow=3),width = 40, height = 40, units = "cm", dpi = 300) 

