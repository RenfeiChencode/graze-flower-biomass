library(ggplot2)
library(scales)
library(patchwork)
library(pracma)

set.seed(123)  
t0_uni<- rnorm(100, mean = 150, sd = 10)
alpha=1;beta=1;tem=290;k=8.62*10^(-5);E=0.65;cycle=4;rh=10;tG=145 
G=alpha*tem/(1+beta*tem)
#######################
### initial no grazed no warming: unimodal distribution
df=data.frame(class=rep(1,length(t0_uni)),flower=t0_uni)
nograze_nowarm=ggplot(df,aes(x = t0_uni,fill = class)) + geom_density(alpha=0.5)+
  labs(title = "No grazed no warming", x = "",y="Probability denstiy")  +
  annotate("text",x=45, y=0.059, label="a",angle = 0,size=15,family="serif")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5),
        axis.text.x=element_text(size=25,family="serif",angle=0,colour = "black",vjust = 0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.position = "none", 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 23,color='black'),
        legend.title = element_text(size = 16,color=NA),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2.5,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm"))+
  scale_x_continuous(breaks=seq(45,245,by=50),limits=c(45,245))+
  scale_y_continuous(breaks=seq(0,0.06,by=0.02),limits=c(0,0.06))


### grazing at time tG no warming; start from the initial stage with no grazing
t0=t0_uni;
tf=matrix(nrow = cycle,ncol = 100);t_op=NA
for (j in 1:cycle){
  for (i in 1:100){
    if(is.na(t0[i])){next 
    }else if(t0[i]<tG){
      RHO=-1*rh
      tf[j,i]=t0[i]+RHO*G
    } else if (t0[i]==tG){RHO=0;tf[j,i]=t0[i]+RHO*G
    }else{RHO=rh;tf[j,i]=t0[i]+RHO*G}
    if (tf[j,i]<=20){tf[j,i]=NA}
  }
  t0=tf[j,];t_op=c(t_op,t0)
  
  if (length(na.omit(t0))<=50) break
}

class=factor(rep(1:j,each=100))
df=data.frame(Generation=class,flower=t_op[-1])
df=na.omit(df)
result_siguni=list();peakTuni <- data.frame()
for (i in 1:j){
  sub_df=subset(df,df$Generation==i)
  result_siguni[[i]]=wilcox.test( sub_df$flower, t0_uni, exact = FALSE)
  print(median(sub_df$flower))
  pdf_obj=density(sub_df$flower)
  peak_indices=findpeaks(pdf_obj$y, npeaks=5,minpeakheight  = 0.0015, minpeakdistance = 1,sortstr=TRUE)
  peak_values <- pdf_obj$x[peak_indices[,2]]
  peak_densities <- peak_indices[,1]
  peak_df=data.frame(peak_values=peak_values,Generation=i)
  peakTuni=rbind(peakTuni,peak_df)
}
result_siguni
peakTuni
graze_nowarm=ggplot(df,aes(x = flower,fill = Generation)) + geom_density(alpha=0.5)+
  labs(title = "Grazed no warming", x = "",y="") +
  geom_vline(xintercept = tG,size=2, col = "red", lty = "dashed")+
  annotate("text",x=45, y=0.059, label="b",angle = 0,size=15,family="serif")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5),
        axis.text.x=element_text(size=25,family="serif",angle=0,colour = "black",vjust = 0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.position = c(0.8,0.75), 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 23,color='black'),
        legend.title = element_text(size = 20,color="black"),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2.5,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm"))+
  scale_x_continuous(breaks=seq(45,245,by=50),limits=c(45,245))+
  scale_y_continuous(breaks=seq(0,0.06,by=0.02),limits=c(0,0.06))

#######################
gama=3.5e+12;tem=c(285,290,295,300)
### warming no grazing;
t0=t0_uni;G=c(0,0,0,0)
tf=matrix(nrow = cycle,ncol = 100);t_op=NA
for (j in 1:cycle){
  for (i in 1:100){
    if(is.na(t0[i])){next 
    }else if(t0[i]<tG){
      RHO=-1*rh
      tf[j,i]=t0[i]-gama*exp(-E/(k*tem[j]))+RHO*G[j]
    } else if (t0[i]==tG){RHO=0;tf[j,i]=t0[i]-gama*exp(-E/(k*tem[j]))+RHO*G[j]
    }else{RHO=rh;tf[j,i]=t0[i]-gama*exp(-E/(k*tem[j]))+RHO*G[j]}
    if (tf[j,i]<=20){tf[j,i]=NA}
  }
  t0=tf[j,];t_op=c(t_op,t0)
  
  if (length(na.omit(t0))<=50) break
}

class=factor(rep(1:j,each=100))
df=data.frame(Generation=class,flower=t_op[-1])
df=na.omit(df)
result_siguni=list();peakTuni <- data.frame()
for (i in 1:j){
  sub_df=subset(df,df$Generation==i)
  result_siguni[[i]]=wilcox.test( sub_df$flower, t0_uni, exact = FALSE)
  print(median(sub_df$flower))
  pdf_obj=density(sub_df$flower)
  peak_indices=findpeaks(pdf_obj$y, npeaks=5,minpeakheight  = 0.0015, minpeakdistance = 1,sortstr=TRUE)
  peak_values <- pdf_obj$x[peak_indices[,2]]
  peak_densities <- peak_indices[,1]
  peak_df=data.frame(peak_values=peak_values,Generation=i)
  peakTuni=rbind(peakTuni,peak_df)
}
result_siguni
peakTuni
nograze_warm=ggplot(df,aes(x = flower,fill = Generation)) + geom_density(alpha=0.5)+
  labs(title = "No grazed with warming", x = "Onset of flowering (Simulative day)",y="Probability denstiy") +
  geom_vline(xintercept = tG,size=2, col = "red", lty = "dashed")+
  annotate("text",x=45, y=0.059, label="c",angle = 0,size=15,family="serif")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5),
        axis.text.x=element_text(size=25,family="serif",angle=0,colour = "black",vjust = 0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.position = c(0.8,0.75), 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 23,color='black'),
        legend.title = element_text(size = 20,color="black"),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2.5,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm"))+
  scale_x_continuous(breaks=seq(45,245,by=50),limits=c(45,245))+
  scale_y_continuous(breaks=seq(0,0.06,by=0.02),limits=c(0,0.06))

###################
### grazing at time tG with warming;
t0=t0_uni;G=alpha*tem/(1+beta*tem)
tf=matrix(nrow = cycle,ncol = 100);t_op=NA
for (j in 1:cycle){
  for (i in 1:100){
    if(is.na(t0[i])){next 
    }else if(t0[i]<tG){
      RHO=-1*rh
      tf[j,i]=t0[i]-gama*exp(-E/(k*tem[j]))+RHO*G[j]
    } else if (t0[i]==tG){RHO=0;tf[j,i]=t0[i]-gama*exp(-E/(k*tem[j]))+RHO*G[j]
    }else{RHO=rh;tf[j,i]=t0[i]-gama*exp(-E/(k*tem[j]))+RHO*G[j]}
    if (tf[j,i]<=20){tf[j,i]=NA}
  }
  t0=tf[j,];t_op=c(t_op,t0)
  
  if (length(na.omit(t0))<=50) break
}

class=factor(rep(1:j,each=100))
df=data.frame(Generation=class,flower=t_op[-1])
df=na.omit(df)
result_siguni=list();peakTuni <- data.frame()
for (i in 1:j){
  sub_df=subset(df,df$Generation==i)
  result_siguni[[i]]=wilcox.test( sub_df$flower, t0_uni, exact = FALSE)
  print(median(sub_df$flower))
  pdf_obj=density(sub_df$flower)
  peak_indices=findpeaks(pdf_obj$y, npeaks=5,minpeakheight  = 0.0015, minpeakdistance = 1,sortstr=TRUE)
  peak_values <- pdf_obj$x[peak_indices[,2]]
  peak_densities <- peak_indices[,1]
  peak_df=data.frame(peak_values=peak_values,Generation=i)
  peakTuni=rbind(peakTuni,peak_df)
}
graze_warm=ggplot(df,aes(x = flower,fill = Generation)) + geom_density(alpha=0.5)+
  labs(title = "Grazed with warming", x = "Onset of flowering (Simulative day)",y="") +
  geom_vline(xintercept = tG,size=2, col = "red", lty = "dashed")+
  annotate("text",x=45, y=0.059, label="d",angle = 0,size=15,family="serif")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5),
        axis.text.x=element_text(size=25,family="serif",angle=0,colour = "black",vjust = 0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.position = c(0.8,0.75), 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 23,color='black'),
        legend.title = element_text(size = 20,color="black"),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2.5,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm"))+
  scale_x_continuous(breaks=seq(45,245,by=50),limits=c(45,245))+
  scale_y_continuous(breaks=seq(0,0.06,by=0.02),limits=c(0,0.06))
#######################
OUTFIG=(nograze_nowarm|graze_nowarm)/(nograze_warm|graze_warm)
OUTFIG
#ggsave("positive graze VS tem2026_5_29.pdf",OUTFIG,width = 45, height = 40, units = "cm", dpi = 300) 

result_siguni
peakTuni
###############figure5e#########
library(rtry);library(patchwork)
library(ggplot2)
library(rtry)
library(lubridate)
df=read.csv("gr2.csv")# analyses about the relationship of biomass vs. onset of flowering;
df2=rtry_select_row(df,
                    (Genus %in% c("Trifolium")),
                    getAncillary = TRUE)
meanAGBmax=aggregate(df2$AGBmax,by=list(type=df2$Onsetflower),mean)
bioup=Onflowerup=biodwn=Onflowerdwn=NA;j=k=1
for (i in 1:length(meanAGBmax$type)){
  if(meanAGBmax$x[i]>=250){bioup[j]=meanAGBmax$x[i];Onflowerup[j]=meanAGBmax$type[i];j=j+1}
  else {biodwn[k]=meanAGBmax$x[i];Onflowerdwn[k]=meanAGBmax$type[i];k=k+1}
}
dfup=data.frame(bio=bioup,Onflower=Onflowerup)
dfdwn=data.frame(bio=biodwn,Onflower=Onflowerdwn)
figempD=ggplot()+
  geom_point(data = dfup,aes(x=Onflower,y=bio),size=4,colour="orange")+geom_smooth(data = dfup,aes(x=Onflower,y=bio),method="loess",span=1,size=2)+
  geom_point(data = dfdwn,aes(x=Onflower,y=bio),size=4,colour="orange")+geom_smooth(data = dfdwn,aes(x=Onflower,y=bio),method="loess",span=1,size=2)+
  labs(title="Trifolium",colour="",x="Onset of flowering (Julian day)",
       y=expression(paste("Mean AGBmax ", (g/m^2))))+
  annotate("text",x=55, y=720, label="e",colour="black",angle = 0,size=10 ,family="serif")+
  theme(axis.text=element_text(size=30,family="serif",colour = "black"),
        axis.text.x = element_text(vjust=0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.1, colour = "black", linetype=1),
        axis.ticks.length = unit(0.15, "cm"),
        axis.ticks = element_line(size = 0.5, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        line = element_blank(),
        legend.key = element_blank(),
        legend.position = c(0.75,0.8), 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 16,color='black'),
        legend.title = element_text(size=16, face = "bold"),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm") )+
  scale_x_continuous(breaks=seq(50,250,by=50),limits=c(50,250))+
  scale_y_continuous(breaks=seq(50,750,by=175),limits=c(50,750))

########figure S16
figemp_app=ggplot()+
  geom_point(data = df2,aes(x=Onsetflower,y=AGBmax),size=4,colour="orange")+#geom_smooth(data = dfdwn,aes(x=Onflower,y=bio),method="loess",span=1,size=2)+
  labs(title="Trifolium",colour="",x="Onset of flowering (Julian day)",
       y=expression(paste("AGBmax ", (g/m^2))))+
  annotate("text",x=55, y=720, label="",colour="black",angle = 0,size=10 ,family="serif")+
  theme(axis.text=element_text(size=30,family="serif",colour = "black"),
        axis.text.x = element_text(vjust=0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.1, colour = "black", linetype=1),
        axis.ticks.length = unit(0.15, "cm"),
        axis.ticks = element_line(size = 0.5, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        line = element_blank(),
        legend.key = element_blank(),
        legend.position = c(0.75,0.8), 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 16,color='black'),
        legend.title = element_text(size=16, face = "bold"),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm") )+
  scale_x_continuous(breaks=seq(50,250,by=50),limits=c(50,250))+
  scale_y_continuous(breaks=seq(50,750,by=175),limits=c(50,750))
#ggsave("figempD.pdf",figempD,width = 20, height = 20, units = "cm", dpi = 300) 
ggsave("figemp_app.pdf",figemp_app,width = 20, height = 20, units = "cm", dpi = 300) 
