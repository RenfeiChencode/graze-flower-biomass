file_list = dir('*.hdf');
file_names = {file_list.name};
time_info = [];
tile_info = [];
file_struct = struct('file_name', {}, 'time', {}, 'tile', {});
for i = 1:length(file_names)
    file_name = file_names{i};
    day_of_year = str2double(file_name(14:16));
    time_info = [time_info; day_of_year];  
    tile_info = [tile_info; string(file_name(18:23))];
    file_struct(i).file_name = file_name;
    file_struct(i).time = day_of_year;
    file_struct(i).tile = string(file_name(18:23));
end
unique_tiles = unique(tile_info);
unique_time=unique(time_info);
tile_groups = struct();
for i = 1:length(unique_tiles)
    tile = unique_tiles{i};
    tile_groups.(tile) = [];
end
for i = 1:length(file_struct)
    tile = file_struct(i).tile;
    tile_groups.(tile) = [tile_groups.(tile); file_struct(i)];
end

final_data = [];
rows=2400;
cols=2400;
start_of_bloom = zeros(rows, cols,length(unique_tiles));
window_size = 9; 
poly_order = 2; 
for i = 1:length(unique_tiles)
    tile = unique_tiles{i};
    tile_group = tile_groups.(tile);
    [sorted_times, sort_idx] = sort([tile_group.time]);
    sorted_files = tile_group(sort_idx);
     tile_data = zeros(rows, cols, length(sorted_files));
    for j = 1:length(sorted_files)
        file_name = sorted_files(j).file_name;
        band1 = cast(hdfread(file_name,'sur_refl_b01'),'int64');%red
        band3 = cast(hdfread(file_name,'sur_refl_b03'),'int64');%blue
        band4 = cast(hdfread(file_name,'sur_refl_b04'),'int64');% green
        sum_band = band1 + band3 + 0.5*band4;
        tile_data(:, :, j) = sum_band;
    end 

    
    for ii = 1:rows
    for jj = 1:cols
        pixel_time_series_smooth = sgolayfilt(tile_data(ii,jj,:), poly_order, window_size);
        pixel_derivative_series = diff(pixel_time_series_smooth);
        threshold = prctile(pixel_derivative_series, 90);
        bloom_start = find(pixel_derivative_series >= threshold, 1, 'first');
        start_of_bloom(ii, jj,i) = unique_time(bloom_start);
    end
    end

info = hdfinfo(file_name);
metadata = info.Attributes(2).Value;
lines = strsplit(metadata, newline);
mtrs = [];
locat=[];
    for iii = [8 9]
    line = lines{iii};
        start_pos = strfind(line, '(') + 1;
        end_pos = strfind(line, ')') - 1;
        mtrs = str2double(strsplit(line(start_pos:end_pos), ','));
        locat=[locat mtrs]
    end
x_min = locat(1);
y_max = locat(2);
x_max = locat(3);
y_min = locat(4);
R = maprasterref('RasterSize', [2400, 2400], ...
    'XWorldLimits', [x_min, x_max], ...
    'YWorldLimits', [y_min, y_max], ...
    'ColumnsStartFrom', 'north', ...
    'RowsStartFrom', 'west');
year = string(file_name(10:13));
output_filename = [year{1} tile '.tif'];
geotiffwrite(output_filename, cast(start_of_bloom(:,:,i),'int16'), R, 'CoordRefSysCode', 32662); 
end

exit;
