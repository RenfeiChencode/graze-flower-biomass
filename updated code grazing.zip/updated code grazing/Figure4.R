library(tidyverse)
library(ggtext)
library(ggdist)
library(geomtextpath)
library(glue)
library(patchwork)
library(rtry)
setwd("C:\\Users\\lenovo\\Desktop")
library(glmmTMB)#generalise linear mixed model
library(MASS)
library(mclust)
library(ggplot2)
library(pracma)
library(dplyr)
########################################
df=read.csv("gr3.csv")
df$Grazed_f=factor(df$Grazed,levels = c(0, 1, 2))
df$Treatment=factor(df$Treatment..Name.of.the.experimental.treatment,levels = unique(df$Treatment..Name.of.the.experimental.treatment))
median_p <- median(df$Onsetflower, na.rm = TRUE)

####
sitename=unique(df$Location...Site.Name);p=list();distance_df=list();df4=df5=df6=data.frame();result_sig=list()
##delete sites with single grazing gradient, which cannot make a comparison:
##"SC-SUT", only low grazing intensity
##"FR-HGM",only no grazing treatment
##"CZ-OHR", only no grazing treatment
sitename=sitename[c(-5,-7,-11)];pvalue=NA
np=c(rep(3,6),2,4,3)
for (i in 1:9){
  df2=rtry_select_row(df,
                      (Location...Site.Name %in% sitename[i]),
                      getAncillary = TRUE)
  df3=data.frame(Onsetflower=df2$Onsetflower,Grazed=df2$Grazed)
  df3 <- na.omit(df3);df3$Grazed=ifelse(df3$Grazed == 0, "Banning", 
                                        ifelse(df3$Grazed == 1, "Low",
                                               ifelse(df3$Grazed == 2, "High", df3$Grazed)))
  df_split <- df3 %>% split(.$Grazed)
  medi_flower=list()
  for (group_name in names(df_split)) {
    sub_df <- df_split[[group_name]]
    pdf_obj=density(sub_df$Onsetflower)
    potential <- -log(pdf_obj$y + 1e-10)
    
    potential_data = data.frame(
      Onsetflower = pdf_obj$x, 
      Potential = potential,
      Grazed=rep(paste(group_name,sitename[i]),length(potential)),
      Site=rep(sitename[i],length(potential)),
      le=rep(group_name,length(potential))
    )
    df4=rbind(df4,potential_data)
    
    extrema = which(diff(sign(diff(potential))) != 0)
    extrema_points = potential_data[extrema, ]
    extrema_points$extype = ifelse(diff(sign(diff(potential)))[extrema] > 0, "Min", "Max")
    
    
    # ========== bootstrap==========
    n_bootstrap = 1000   
    bootstrap_minima_positions = list()  
    bootstrap_minima_potential = list()  
    
    n_obs = nrow(sub_df) 
    
    for (b in 1:n_bootstrap) {
      
      boot_idx = sample(n_obs, size = n_obs, replace = TRUE)
      boot_data = sub_df$Onsetflower[boot_idx]
      
      
      boot_pdf = density(boot_data)
      boot_potential = -log(boot_pdf$y + 1e-10)
      
     
      boot_extrema = which(diff(sign(diff(boot_potential))) != 0)
      
      if (length(boot_extrema) > 0) {
        boot_extrema_types = diff(sign(diff(boot_potential)))[boot_extrema]
        boot_minima_indices = boot_extrema[boot_extrema_types > 0]  
        
        if (length(boot_minima_indices) > 0) {
          bootstrap_minima_positions[[b]] = boot_pdf$x[boot_minima_indices]
          bootstrap_minima_potential[[b]] = boot_potential[boot_minima_indices]
        } else {
          bootstrap_minima_positions[[b]] = numeric(0)
          bootstrap_minima_potential[[b]] = numeric(0)
        }
      } else {
        bootstrap_minima_positions[[b]] = numeric(0)
        bootstrap_minima_potential[[b]] = numeric(0)
      }
    }
    
   
    all_bootstrap_positions = unlist(bootstrap_minima_positions)
    
    minima_points = extrema_points[extrema_points$extype == "Min", ]
    
    
    if (nrow(minima_points) > 0 && length(all_bootstrap_positions) > 0) {
      minima_points$boot_mean = NA
      minima_points$boot_sd = NA
      minima_points$ci_lower = NA
      minima_points$ci_upper = NA
      minima_points$stability_freq = NA
      minima_points$significant = FALSE
      
      for (m in 1:nrow(minima_points)) {
        candidate_pos = minima_points$Onsetflower[m]
        
        distances = abs(all_bootstrap_positions - candidate_pos)
        
        neighbor_radius = pdf_obj$bw
        
        in_neighborhood = all_bootstrap_positions[distances < neighbor_radius]
        
        minima_points$stability_freq[m] = length(in_neighborhood) / n_bootstrap
        
        if (length(all_bootstrap_positions) > 1) {
          minima_points$boot_mean[m] = mean(all_bootstrap_positions)
          minima_points$boot_sd[m] = sd(all_bootstrap_positions)
          minima_points$ci_lower[m] = quantile(all_bootstrap_positions, 0.025)
          minima_points$ci_upper[m] = quantile(all_bootstrap_positions, 0.975)
        } else if (length(all_bootstrap_positions) == 1) {
          minima_points$boot_mean[m] = all_bootstrap_positions[1]
          minima_points$boot_sd[m] = 0
          minima_points$ci_lower[m] = candidate_pos - neighbor_radius
          minima_points$ci_upper[m] = candidate_pos + neighbor_radius
        }
        
        # significance
        within_ci = (candidate_pos >= minima_points$ci_lower[m] && 
                       candidate_pos <= minima_points$ci_upper[m])
        minima_points$significant[m] = (within_ci && minima_points$stability_freq[m] >= 0.5)
      }
      

      for (m in 1:nrow(minima_points)) {
        idx = which(extrema_points$Onsetflower == minima_points$Onsetflower[m] & 
                      extrema_points$extype == "Min")
        if (length(idx) > 0) {
          extrema_points$boot_mean[idx] = minima_points$boot_mean[m]
          extrema_points$boot_sd[idx] = minima_points$boot_sd[m]
          extrema_points$ci_lower[idx] = minima_points$ci_lower[m]
          extrema_points$ci_upper[idx] = minima_points$ci_upper[m]
          extrema_points$stability_freq[idx] = minima_points$stability_freq[m]
          extrema_points$significant[idx] = minima_points$significant[m]
        }
      }
    } else {
      extrema_points$boot_mean = NA
      extrema_points$boot_sd = NA
      extrema_points$ci_lower = NA
      extrema_points$ci_upper = NA
      extrema_points$stability_freq = NA
      extrema_points$significant = FALSE
    }
    extrema_points = extrema_points[extrema_points$significant == TRUE, ]
    
    df5=rbind(df5,extrema_points)
    
    median_p = median(sub_df$Onsetflower)
    medi_flower[[group_name]]=sub_df
    # a table with min and max 
    num=table(extrema_points$extype);
    num_df=data.frame(Grazed=group_name,number_min=num["Min"],
                      median_group=paste(group_name,sitename[i]),median_p=median_p,site=sitename[i])
    df6=rbind(df6,num_df)
    
  }
  result_sig[[i]]=wilcox.test( medi_flower[[1]]$Onsetflower, medi_flower[[2]]$Onsetflower, exact = FALSE)
  
  pvalue=c(pvalue,rep(result_sig[[i]]$p.value,length(names(df_split))))
  
}
df6=cbind(df6,round(data.frame(pvalue=na.omit(pvalue)),3))
freq_min=df6 %>% group_by(Grazed, number_min)%>% summarise(count = n(),.groups = "drop")# %>% mutate(frequency = count / sum(count))
freq_min$Grazed=factor(freq_min$Grazed,levels = c("Banning","Low", "High"))
#FMIN=ggplot(freq_min, aes(x = Grazed, y = frequency, fill = as.factor(number_min))) +
#  geom_bar(stat = "identity", position = "dodge")

df4low=subset(df4,df4$le=="Low");df5low=subset(df5,df5$le=="Low")
Potential_low=ggplot(df4low,aes(y=Potential,x = Onsetflower, group=Site,color= Site)) +geom_path(size=1) +
  geom_point(data=df5low, aes(y=Potential,x = Onsetflower, group=Site,color= Site), size=3)+
  labs(title = "Low grazing intensity", x = "Onset of flowering",y="",color="Site") +
  annotate("text",x=2.5, y=17.5, label="b",angle = 0,size=10,family="serif")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        #axis.text.x = element_text(vjust=0.0,size=20),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        #axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA),
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.text =element_text(size = 18,color='black'),
        legend.key.size = unit(1.5,'line'), # space between legend text
        legend.title = element_text(size = 18,color='black'),
        legend.position = c(0.5,0.8),
        legend.direction = "horizontal",
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm")) + guides(color = guide_legend(nrow = 3))+
  scale_x_continuous(breaks=seq(0,300,by=100),limits=c(0,300))+
  scale_y_continuous(breaks=seq(0,18,by=6),limits=c(0,18))

df4high=subset(df4,df4$le=="High");df5high=subset(df5,df5$le=="High")
Potential_high=ggplot(df4high,aes(y=Potential,x = Onsetflower, group=Site,color= Site)) +geom_path(size=1) +
  geom_point(data=df5high, aes(y=Potential,x = Onsetflower, group=Site,color= Site), size=3)+
  labs(title = "High grazing intensity", x = "Onset of flowering",color="Site") +
  annotate("text",x=2.5, y=17.5, label="c",angle = 0,size=10,family="serif")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        #axis.text.x = element_text(vjust=0.0,size=20),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        #axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA),
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.text =element_text(size = 18,color='black'),
        legend.key.size = unit(1.5,'line'), # space between legend text
        legend.title = element_text(size = 18,color='black'),
        legend.position =  c(0.5,0.8),
        legend.direction = "horizontal",
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm")) +
  scale_x_continuous(breaks=seq(0,300,by=100),limits=c(0,300))+
  scale_y_continuous(breaks=seq(0,18,by=6),limits=c(0,18))

df4ban=subset(df4,df4$le=="Banning");df5ban=subset(df5,df5$le=="Banning")
Potential_ban=ggplot(df4ban,aes(y=Potential,x = Onsetflower, group=Site,color= Site)) +geom_path(size=1) +
  geom_point(data=df5ban, aes(y=Potential,x = Onsetflower, group=Site,color= Site), size=3)+
  labs(title = "No grazing", x = "",color="Site") +
  annotate("text",x=2.5, y=17.5, label="a",angle = 0,size=10,family="serif")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        #axis.text.x = element_text(vjust=0.0,size=20),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        #axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA),
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.text =element_text(size = 18,color='black'),
        legend.key.size = unit(1.5,'line'), # space between legend text
        legend.title = element_text(size = 18,color='black'),
        legend.position =  c(0.5,0.8),
        legend.direction = "horizontal",
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm")) +
  scale_x_continuous(breaks=seq(0,300,by=100),limits=c(0,300))+
  scale_y_continuous(breaks=seq(0,18,by=6),limits=c(0,18))

df7=data.frame(group=c("Advance","Neutral","Delay"),value=c(2/9, 4/9, 3/9))
df7$group=factor(df7$group,levels = c("Advance","Neutral","Delay"))
df7$labal=sprintf("%.2f%%", df7$value * 100)
MEDIAN_plot=ggplot(df7, aes(x = group, y = value)) +
  geom_bar(stat = "identity", position = "dodge",fill="blue")+
  labs(title = "Shift of onset of flowering", x = "Median difference", y = "Relative frequency") +
  annotate("text",x=0.6, y=0.75, label="e",angle = 0,size=9,family="serif")+
  annotate("text",x=1, y=0.28, label=df7$labal[1],angle = 0,size=9,family="serif")+
  annotate("text",x=2, y=0.6, label=df7$labal[2],angle = 0,size=9,family="serif")+
  annotate("text",x=3, y=0.4, label=df7$labal[3],angle = 0,size=9,family="serif")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        #axis.text.x = element_text(vjust=0.0,size=20),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        #axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm")) +
  scale_y_continuous(breaks=seq(0,0.8,by=0.2),limits=c(0,0.8))
Vfreq_banning=subset(freq_min,freq_min$Grazed=="Banning")
stable_banning=sum(Vfreq_banning$count[Vfreq_banning$number_min==1])/sum(Vfreq_banning$count)
Vfreq_low=subset(freq_min,freq_min$Grazed=="Low")
stable_low=sum(Vfreq_low$count[Vfreq_low$number_min==1])/sum(Vfreq_low$count)
Vfreq_high=subset(freq_min,freq_min$Grazed=="High")
stable_high=sum(Vfreq_high$count[Vfreq_high$number_min==1])/sum(Vfreq_high$count)
df8=data.frame(group=c("Banning","Banning","Low","Low","High"),value=c(stable_banning,1-stable_banning,
                                                                       stable_low,1-stable_low,1))
df8$labal=c("Stable","Unstable","Stable","Unstable","Unstable")
df8$labper=sprintf("%.2f%%", df8$value * 100)
df8$group=factor(df8$group,levels = c("Banning","Low","High"))
stable_point=ggplot(df8, aes(x = group, y = value,fill=labal)) +geom_bar(stat = "identity", position = "dodge")+
  labs(title = "Stability of onset of flowering", x = "Grazing intensity", y = "Relative frequency",fill="") +
  annotate("text",x=0.6, y=0.95, label="d",angle = 0,size=10,family="serif")+
  annotate("text",x=0.8, y=df8$value[1]+0.03, label=df8$labper[1],angle = 0,size=9,family="serif")+
  annotate("text",x=1.2, y=df8$value[2]-0.03, label=df8$labper[2],angle = 0,size=9,family="serif")+
  annotate("text",x=1.8, y=df8$value[3]+0.03, label=df8$labper[3],angle = 0,size=9,family="serif")+
  annotate("text",x=2.2, y=df8$value[4]-0.03, label=df8$labper[4],angle = 0,size=9,family="serif")+
  annotate("text",x=3, y=0.5, label=df8$labper[5],angle = 0,size=9,family="serif")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        #axis.text.x = element_text(vjust=0.0,size=20),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        #axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        legend.position = c(0.1,0.55),
        legend.text =element_text(size = 15,color='black'),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm")) +
  scale_y_continuous(breaks=seq(0,1,by=0.25),limits=c(0,1))

###############################################################
#ggsave("distribution total.pdf",pt,width = 20, height = 20, units = "cm", dpi = 300) 
#ggsave("distribution each site_part.pdf",(p[[1]]|p[[2]]|p[[4]])/(p[[3]]|p[[5]]|p[[6]])/(p[[9]]|p[[8]]|p[[7]]),width = 70, height = 60, units = "cm", dpi = 300) 
#for (i in 1:9){
#  write.table(distance_df[[i]], file = 'distance.csv',sep = ",",row.names = FALSE, col.names = TRUE, append = TRUE)
#}
#write.csv(df6,"中值显著性最小极值点数量.csv")
#ggsave("potential and median.pdf",Potential_plot|stable_point|MEDIAN_plot,width = 70, height = 20, units = "cm", dpi = 300) 
ggsave("potential.pdf",(Potential_ban|Potential_low)/(Potential_high|(stable_point/MEDIAN_plot)),width = 45, height = 45, units = "cm", dpi = 300) 


