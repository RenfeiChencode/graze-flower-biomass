library(ggplot2)
library(scales)
library(patchwork)
library(pracma)

set.seed(123)  
t1<- rnorm(50, mean = 100, sd = 10)
t2<- rnorm(50, mean = 150, sd = 10)
t0_bi=c(t1,t2)
t0_uni<- rnorm(100, mean = 150, sd = 10)
alpha=1;beta=1;tem=290;k=8.62*10^(-5);E=0.65;cycle=10
G=alpha*tem/(1+beta*tem)

###############################
# ========Figure 5a============
### initial no grazing: bimodal distribution
df=data.frame(class=rep(1,length(t0_bi)),flower=t0_bi)
nograze_bi=ggplot(df,aes(x = t0_bi,fill = class)) + geom_density(alpha=0.5)+
  labs(title = "No grazed \n Bimodal distribution", x = "",y="Probability denstiy")  +
  annotate("text",x=0, y=0.02, label="a",angle = 0,size=15,family="sans")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5,margin = margin(0,5,0,0)),
        axis.text.x=element_text(size=25,family="serif",angle=0,colour = "black",vjust = 0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.position = "none", 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 23,color='black'),
        legend.title = element_text(size = 16,color=NA),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2.5,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = 0.3, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm"))+
  scale_x_continuous(breaks=seq(0,200,by=50),limits=c(0,200))+
  scale_y_continuous(breaks=seq(0,0.02,by=0.02/4),limits=c(0,0.02))


### grazing at time tG; start from the initial stage with no grazing
t0=t0_bi;rh=30;tG=200 # grazing time
tf=matrix(nrow = cycle,ncol = 100);t_op=NA
for (j in 1:cycle){
for (i in 1:100){
  if(is.na(t0[i])){next 
  }else if(t0[i]<tG){
   RHO=-1*rh
   tf[j,i]=t0[i]-exp(-E/(k*tem))+RHO*G
 } else if (t0[i]==tG){RHO=0;tf[j,i]=t0[i]-exp(-E/(k*tem))+RHO*G
 }else{RHO=rh;tf[j,i]=t0[i]-exp(-E/(k*tem))+RHO*G}
  if (tf[j,i]<=20){tf[j,i]=NA}
}
t0=tf[j,];t_op=c(t_op,t0)

if (length(na.omit(t0))<=50) break
}

class=factor(rep(1:j,each=100))
df=data.frame(Generation=class,flower=t_op[-1])
df=na.omit(df)
result_sigbi=list();peakTbi <- data.frame()
for (i in 1:j){
  sub_df=subset(df,df$Generation==i)
  result_sigbi[[i]]=wilcox.test( sub_df$flower, t0_bi, exact = FALSE)
  print(median(sub_df$flower))
  pdf_obj=density(sub_df$flower)
  peak_indices=findpeaks(pdf_obj$y, npeaks=5,minpeakheight  = 0.0015, minpeakdistance = 1,sortstr=TRUE)
  peak_values <- pdf_obj$x[peak_indices[,2]]
  peak_densities <- peak_indices[,1]
  peak_df=data.frame(peak_values=peak_values,Generation=i)
  peakTbi=rbind(peakTbi,peak_df)
}
# ========Figure 5b============
graze_bi=ggplot(df,aes(x = flower,fill = Generation)) + geom_density(alpha=0.5)+
  labs(title = "Grazed selection \n Initial bimodal distribution", x = "",y="") +
  geom_vline(xintercept = tG,size=1.2, col = "red", lty = "dashed")+
  annotate("text",x=0, y=0.059, label="b",angle = 0,size=15,family="sans")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5,margin = margin(0,5,0,0)),
        axis.text.x=element_text(size=25,family="serif",angle=0,colour = "black",vjust = 0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.position = c(0.8,0.75), 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 23,color='black'),
        legend.title = element_text(size = 25,color="black"),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2.5,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = -0.0, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm"))+
  scale_x_continuous(breaks=seq(0,200,by=50),limits=c(0,200))+
  scale_y_continuous(breaks=seq(0,0.06,by=0.02),limits=c(0,0.06))

#######################
# ========Figure 5c============
### initial no grazing: unimodal distribution
df=data.frame(class=rep(1,length(t0_uni)),flower=t0_uni)
nograze_uni=ggplot(df,aes(x = t0_uni,fill = class)) + geom_density(alpha=0.5)+
  labs(title = "Unimodal distribution", x = "Onset of flowering",y="Probability denstiy")  +
  annotate("text",x=45, y=0.0448, label="c",angle = 0,size=15,family="sans")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5,margin = margin(0,5,0,0)),
        axis.text.x=element_text(size=25,family="serif",angle=0,colour = "black",vjust = 0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.position = "none", 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 23,color='black'),
        legend.title = element_text(size = 16,color=NA),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2.5,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = 0.3, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm"))+
  scale_x_continuous(breaks=seq(45,245,by=50),limits=c(45,245))+
  scale_y_continuous(breaks=seq(0,0.045,by=0.045/3),limits=c(0,0.045))


### grazing at time tG; start from the initial stage with no grazing
t0=t0_uni;rh=10;tG=145;cycle=4 # grazing time
tf=matrix(nrow = cycle,ncol = 100);t_op=NA
for (j in 1:cycle){
  for (i in 1:100){
    if(is.na(t0[i])){next 
    }else if(t0[i]<tG){
      RHO=-1*rh
      tf[j,i]=t0[i]-exp(-E/(k*tem))+RHO*G
    } else if (t0[i]==tG){RHO=0;tf[j,i]=t0[i]-exp(-E/(k*tem))+RHO*G
    }else{RHO=rh;tf[j,i]=t0[i]-exp(-E/(k*tem))+RHO*G}
    if (tf[j,i]<=20){tf[j,i]=NA}
  }
  t0=tf[j,];t_op=c(t_op,t0)
  
  if (length(na.omit(t0))<=50) break
}

class=factor(rep(1:j,each=100))
df=data.frame(Generation=class,flower=t_op[-1])
df=na.omit(df)
result_siguni=list();peakTuni <- data.frame()
for (i in 1:j){
  sub_df=subset(df,df$Generation==i)
  result_siguni[[i]]=wilcox.test( sub_df$flower, t0_uni, exact = FALSE)
  print(median(sub_df$flower))
  pdf_obj=density(sub_df$flower)
  peak_indices=findpeaks(pdf_obj$y, npeaks=5,minpeakheight  = 0.0015, minpeakdistance = 1,sortstr=TRUE)
  peak_values <- pdf_obj$x[peak_indices[,2]]
  peak_densities <- peak_indices[,1]
  peak_df=data.frame(peak_values=peak_values,Generation=i)
  peakTuni=rbind(peakTuni,peak_df)
}
# ========Figure 5d============
graze_uni=ggplot(df,aes(x = flower,fill = Generation)) + geom_density(alpha=0.5)+
  labs(title = "Initial unimodal distribution", x = "Onset of flowering",y="") +
  geom_vline(xintercept = tG,size=1.2, col = "red", lty = "dashed")+
  annotate("text",x=45, y=0.039, label="d",angle = 0,size=15,family="sans")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5,margin = margin(0,5,0,0)),
        axis.text.x=element_text(size=25,family="serif",angle=0,colour = "black",vjust = 0.0),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA), 
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.position = c(0.8,0.75), 
        legend.background = element_rect(fill = "NA", color = NA),
        legend.text =element_text(size = 23,color='black'),
        legend.title = element_text(size = 25,color="black"),
        legend.direction="vertical", #horizontal; vertical
        legend.key.size = unit(2.5,'line'), # space between legend text
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = 0.3, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.3, b=0.2, l=0.12, "cm"))+
  scale_x_continuous(breaks=seq(45,245,by=50),limits=c(45,245))+
  scale_y_continuous(breaks=seq(0,0.04,by=0.01),limits=c(0,0.04))
OUTFIG=(nograze_bi|graze_bi)/(nograze_uni|graze_uni)
OUTFIG
#ggsave("Figure5.pdf",OUTFIG,width = 45, height = 40, units = "cm", dpi = 600) 

result_sigbi
result_siguni
peakTbi
peakTuni


##########empirical data figure
# ========Figure 5e============
library(rtry);library(patchwork)
library(ggplot2)
library(rtry)
library(lubridate)
#####################
df=read.csv("gr2.csv")# analyses about the relationship of biomass vs. onset of flowering; distribution pattern (alternative stable state) of flowering time
df2=rtry_select_row(df,
                    (SpeciesName %in% c("Plantago lanceolata","Dactylis glomerata","Trifolium pratense",
                                        "Anthoxanthum odoratum","Ranunculus acris")),
                    getAncillary = TRUE)
df2=rtry_select_row(df,
                    (Genus %in% c("Trifolium")),
                    getAncillary = TRUE)
meanAGBmax=aggregate(df2$AGBmax,by=list(type=df2$Onsetflower),mean)
bioup=Onflowerup=biodwn=Onflowerdwn=NA;j=k=1
for (i in 1:length(meanAGBmax$type)){
  if(meanAGBmax$x[i]>=250){bioup[j]=meanAGBmax$x[i];Onflowerup[j]=meanAGBmax$type[i];j=j+1}
  else {biodwn[k]=meanAGBmax$x[i];Onflowerdwn[k]=meanAGBmax$type[i];k=k+1}
}
dfup=data.frame(bio=bioup,Onflower=Onflowerup)
dfdwn=data.frame(bio=biodwn,Onflower=Onflowerdwn)
figempD=ggplot()+
  geom_point(data = dfup,aes(x=Onflower,y=bio),size=4,colour="orange")+geom_smooth(data = dfup,aes(x=Onflower,y=bio),method="loess",span=1,size=2)+
  geom_point(data = dfdwn,aes(x=Onflower,y=bio),size=4,colour="orange")+geom_smooth(data = dfdwn,aes(x=Onflower,y=bio),method="loess",span=1,size=2)+
  labs(title="Trifolium",colour="",x="Onset of flowering (Julian day)",
       y=expression(paste("Vegetation biomass ", (g/m^2))))+
  #annotate("text",x=55, y=720, label="a",colour="black",angle = 0,size=10 ,family="sans")+
  theme(axis.text=element_text(size=25,family="serif",colour = "black"),
        axis.text.x=element_text(size=25,family="serif",angle=0,colour = "black",vjust = 0.0),
        axis.text.y=element_text(size=25,family="serif",angle=0,colour = "black",hjust = 0.5,vjust = 0.5,margin = margin(0,5,0,0)),
        axis.title=element_text(size=30,family="serif", angle=0, face="plain"),
        axis.title.x = element_text(vjust=0.0),
        axis.line=element_line(size = 0.5, colour = "black", linetype=1),
        axis.ticks.length = unit(0.25, "cm"),
        axis.ticks = element_line(size = 1, color="black"),
        plot.background = element_rect(fill = "white", color = NA),
        panel.border = element_rect(size = 2.0,colour = "black",fill = "NA", linetype=1),
        panel.background = element_rect(fill = "white", color = NA),
        legend.text =element_text(size = 25,color='black'),
        legend.key.size = unit(2.2,'line'), # space between legend text
        # legend.title = element_text(size = 18,color='black'),
        legend.title=element_blank(),
        legend.position = c(0.75,0.8),
        legend.direction = "horizontal",
        plot.title = element_text(size=30, hjust=0.5, color = "black", face = "bold",
                                  margin = margin(b = 0.3, t = 0.4, l = 0, unit = "cm")),
        plot.margin = margin(t=0.2, r=0.6, b=0.2, l=0.12, "cm")) + guides(color = guide_legend(nrow = 3))+
  scale_x_continuous(breaks=seq(50,250,by=50),limits=c(50,250))+
  scale_y_continuous(breaks=seq(50,750,by=175),limits=c(50,750))

###########numerical simulation
# ========Figure 5f============
basedir <- "C:\\Users\\Lenovo\\Desktop\\"
datadir <- paste0(basedir, "fig4equilibrium\\")
modeldir <- paste0(basedir, "fig4equilibrium\\")
fname <- paste0(basedir, "fig4equilibrium\\fig4equilibrium2025_10_212.pdf")
setwd(basedir)
library(ggplot2);library(gridExtra);library(lmodel2);library(scales);library(grid)
library(tseries)# test the stability of time series
library(sqldf);library(dplyr);library(patchwork);library(ggsignif)
library(PSPManalysis)
library(latex2exp)
library(shape)
library(igraph)
library(DescTools)
library(gridGraphics)
library(cowplot)
####################################################################
ToPdf <- T
EBT_PSPM_cmp <- F
#1 nursery; 2 harvested area; 3 protected area
EBTtcol         <-  1
EBTres1col      <-  2
EBTres2col      <-  3
EBTres3col      <-  4
EBTtotnumcol    <-  5
EBTtotbiocol    <-  6
EBTh1numcol     <-  7
EBTh1biocol     <-  8
EBTh2numcol     <-  9
EBTh2biocol     <- 10
EBTh3numcol     <- 11
EBTh3biocol     <- 12
EBTh2juvnumcol  <- 13
EBTh2juvbiocol  <- 14
EBTh3juvnumcol  <- 15
EBTh3juvbiocol  <- 16
EBTh2adunumcol  <- 17
EBTh2adubiocol  <- 18
EBTh3adunumcol  <- 19
EBTh3adubiocol  <- 20
EBTsmoltsizecol <- 21   
EBTtotreprocol  <- 22
EBTnumcohcol    <- 23
EBTyieldjuv     <- 24
EBTyieldadu     <- 25
EBTyieldtot     <- 26
EBTbifparcol    <- 27
EBTperiodcol    <- 28

PSPMbifparcol    <-  1
PSPMres1col      <-  2
PSPMres2col      <-  3
PSPMres3col      <-  4
PSPMh1biocol     <-  9
PSPMh2juvbiocol  <- 10
PSPMh3juvbiocol  <- 11
PSPMh2adubiocol  <- 12
PSPMh3adubiocol  <- 13
PSPMh1numcol     <- 14
PSPMh2numcol     <- 15
PSPMh3numcol     <- 16

iArrows <- igraph:::igraph.Arrows
DefaultPars <- c(Rho1 = 0.5, Rho2 =    0.5, Delta = 1.0, 
                 Eta1 = 1.0, Eta2 =    0.8, Eta3  = 0.8, 
                 ETSJ = 1.4, ETSA =    1.4, WS    = 0.35, 
                 Q    = 1.0, Beta = 2000.0, SR    = 0.0)
layout(matrix(1:1, nrow = 1, ncol = 1), widths = c(1.0, rep(1.0, 1)), heights = rep(c(0.98, 1.3), 1))
xlimc <- c(-0.0, 1.0)
xlimw <- c(0.05, 0.45)
ylim1 <- c(-0.05, 1.05)
ylim2 <- c(-0.02, 0.4)

cexlab <- 2.0
cexaxs <- 2.0
cexleg <- 1.8
cexttl <- 2.2
cexpnt <- 2.0
cexbt  <- 1.6

axislwd <- 3

par(tcl = 0.6, mgp = c(3, 1, 0))

lwd=2

init=c(0.05, 0.9142577824,	0.2843496419,	0.1620576624, 1)#######
pars <- DefaultPars
pars["SR"] <- 0.25
if (!exists("Equi_SR03_Ws")) {
  Equi_SR03_Ws <- PSPMequi(modelname = paste0(modeldir, "HarvestWithReserve"), 
                           biftype = "EQ", startpoint = init, 
                           stepsize = 0.01, parbnds = c(8, 0.05, 0.5), 
                           parameters = pars, clean=TRUE, 
                           options = c("popEVO", "0"))
}

dt          <- Equi_SR03_Ws$curvepoints
dtbp        <- Equi_SR03_Ws$bifpoints
dtbt        <- Equi_SR03_Ws$biftypes

EBTdt       <- read.table(paste0(datadir, "fig4c025evo14dwn.minmax2.out"))
EBTmax      <- EBTdt[2 * (1:(nrow(EBTdt) / 2.0)),]
EBTmin      <- EBTdt[2 * (1:(nrow(EBTdt) / 2.0)) - 1,]

stable      <- EBTmax[, EBTperiodcol] > 1.0E-4
indx2       <- nrow(EBTmax)
indx1       <- max((1:indx2)[stable]) + 1
EBTdwnM     <- rbind(EBTmax[(1:indx1),], EBTmin[(indx1:1),])
stable      <- dt[, PSPMbifparcol] < min(EBTdwnM[, EBTbifparcol])

par(mar = c(6, 10, 4.0, 2.5))
indx1 <- which.min(abs(dt[,PSPMbifparcol] - dtbp[1,PSPMbifparcol]))
indx2 <- which.min(abs(dt[,PSPMbifparcol] - dtbp[3,PSPMbifparcol]))
indx3 <- max((indx2:nrow(dt))[dt[(indx2:nrow(dt)),PSPMbifparcol] < min(EBTdwnM[,EBTbifparcol])])



base_plot <- function() {
  par(lwd=3)
  par(mar = c(6, 6, 4.0, 2.5))
  #ylim2 <- c(0.0, 0.4)
  plot(NULL, NULL, xlim = xlimw, ylim = ylim2, 
       xlab = "", ylab = "", xaxs = "i", yaxs = "i",
       xaxt = "n", yaxt = "n")
  axis(1, at = 0.05 + (0:4) * 0.1, label = c("0.05", "0.15", "0.25", "0.35","0.45"), 
       cex.axis = cexaxs, lwd = 3, lwd.ticks = axislwd)
  axis(2, at = (0:4) * 0.1, label = c("0.0", "0.1", "0.2", "0.3", "0.4"), 
       cex.axis = cexaxs, lwd = 3, lwd.ticks = axislwd, las = 2)
  mtext("Biomass (equilibrium)", 2, cex = cexlab, line = 4.8)
  mtext("Onset of flowering", 1, cex = cexlab, line = 4.5)
  mtext("75% grazed", 3, cex = cexttl, line = 1.0)
  
  lines(dt[(1:indx1),PSPMbifparcol], dt[(1:indx1),PSPMh2juvbiocol] + dt[(1:indx1),PSPMh2adubiocol], lwd = 2 * lwd, col = "red")
  lines(dt[(indx1:indx2),PSPMbifparcol], dt[(indx1:indx2),PSPMh2juvbiocol] + dt[(indx1:indx2),PSPMh2adubiocol], lwd = lwd, lty = 3, col = "black")
  lines(dt[(indx2:indx3),PSPMbifparcol], dt[(indx2:indx3),PSPMh2juvbiocol] + dt[(indx2:indx3),PSPMh2adubiocol], lwd = 2 * lwd, col = "red")
  lines(dt[(indx3:nrow(dt)),PSPMbifparcol], dt[(indx3:nrow(dt)),PSPMh2juvbiocol] + dt[(indx3:nrow(dt)),PSPMh2adubiocol], lwd = lwd, col = "black", lty = 2)
  
  lines(EBTdwnM[,EBTbifparcol], EBTdwnM[,EBTh2biocol], lwd = lwd, col = "orange")
  points(dtbp[1,PSPMbifparcol],dtbp[1,PSPMh2juvbiocol] + dtbp[1,PSPMh2adubiocol], pch = 19, col = "red", cex = cexpnt)
  points(dtbp[3,PSPMbifparcol], dtbp[3,PSPMh2juvbiocol] + dtbp[3,PSPMh2adubiocol], pch = 19, col = "red", cex = cexpnt)
  
  Arrows(0.09, 0.09, 0.16, 0.09, arr.type="triangle", lwd = 5, arr.width = 0.2, col = "black")
  Arrows(0.44, 0.27, 0.37, 0.27, arr.type="triangle", lwd = 5, arr.width = 0.2, col = "black")
  legend("topleft", legend = c("Stable", "Unstable","Minimum / maximum"), col = c("red","black","orange"), lty = c(1,2,1), cex = cexbt,lwd = c(4,2,2))
}

combine=plot_grid(figempD,base_plot, 
                  #labels = c("a", "b"), 
                  ncol = 2, nrow = 1)
#ggsave("combined_new.pdf",combine,width = 54, height = 20, units = "cm", dpi = 300) 
